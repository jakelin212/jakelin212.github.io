#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The script will: 
a) identify the files and their bin names
b) make the necessary folders where the data will be put in
c) run the filtering procedure as if it were in Galaxy. 


"""
#---IMPORTS-----------------------------------------------------------------------------
from __future__ import absolute_import, division, generators, nested_scopes, print_function, unicode_literals, with_statement


#import Tkinter as tk
#from Tkinter import messagebox
#from Tkinter.filedialog import *
#from Tkinter import ttk
#from Tkinter.ttk import Combobox

import re
import os.path
from os import listdir
from os.path import isfile, join
import io
import time
import sys
import shutil
import gzip

#add these three lines also into the invoked scripts:
import os, sys
import configparser#ConfigParser
config = configparser.RawConfigParser()
config.read('/var/www/cgi-bin/virp/scripts/ref_bin.cfg')
fastqtool_dir = config.get("paths", "toolfastq")

#one_dir = r"/home/ngsuziv/galaxy-dist/lib"
#one_dir = r"/home/lljali/galaxy/lib"
galaxy_lib_dir = config.get("paths", "galaxylib")
galaxy_seq_dir = config.get("paths", "galaxyseqlib")
os.system(r"export PYTHONPATH=$PYTHONPATH:" + galaxy_lib_dir + ":" + galaxy_seq_dir)
sys.path.append(galaxy_lib_dir)
sys.path.append(galaxy_seq_dir)
sys.path.append(r"/home/lljali/galaxy/lib/galaxy_utils/sequence")
#/home/lljali/galaxy/lib/galaxy_utils/sequence

import transform
#dirs = [r"/home/ngsuziv/galaxy-dist/lib/",
#        r"/home/ngsuziv/galaxy-dist/lib/galaxy",
#        r"/home/ngsuziv/galaxy-dist/lib/galaxy_utils",
#        r"/home/ngsuziv/galaxy-dist/lib/galaxy_utils/sequence", 
#        r"/home/ngsuziv/galaxy-dist/lib/galaxy_utils/sequence/fastq",
#        r"/home/ngsuziv/galaxy-dist/tools/fastq"]
#
#for one_dir in dirs:
#    os.system(r"export PYTHONPATH=$PYTHONPATH:" + one_dir)
#    sys.path.append(one_dir)
#    print(sys.path)
#    print("\n\n\n")


from galaxy_utils.sequence.fastq import fastqReader, fastqWriter

import script_for_velvet

#---------------------- global vars -----------------------------






#------- CLASSES --------------------------------------------------------------------------

  

    

#---SUBS--------------------------------------------------------------------------------
def process_original_files(base_dir, prefix, discard_originals = True):
    '''processes the directory for occurrence of the sequencing files, makes the directories and works with the sequencing files'''

    #identify the list of bins
    assert os.path.isdir(base_dir), "The base directory does not exist"
    os.chdir(base_dir)
    file_names = [ f for f in listdir(base_dir) if isfile(os.path.join(base_dir,f)) ]
    print(file_names)
    
    data_dir = os.path.join(base_dir, "data")
    if not os.path.isdir(data_dir):
        os.mkdir(data_dir)
        
    dir_bins = {} #list of all bins to be processed: bin name: file
    
    for file_name in list(file_names):
        pattern = "^" + prefix + r"(\d+)_S(\d+)_L001_R(\d+)_001\.fastq(\.gz)?"
        print(file_name, "\n", pattern)
        result = re.search(pattern, file_name)
        if result:
            bin_num         = result.group(1)
            s_num           = result.group(2)
            read_direction  = result.group(3)
            gzip_extension  = result.group(4)       
            print(bin_num, s_num, read_direction, gzip_extension)

            #make the bin directory in /data
            bin_dir = os.path.join(data_dir, "bin%02d" % int(bin_num))
            if not os.path.isdir(bin_dir):
                os.mkdir(bin_dir)
            #move in the file
            new_file_name = os.path.normpath(os.path.join(bin_dir, "bin%02d_S%d_L001_R%d_001.fastq"
                                               % (int(bin_num), int(s_num), int(read_direction))) )
            
            if gzip_extension is None:
                shutil.copy(file_name, new_file_name)
            else:
                inF = gzip.open(file_name, 'rb')
                outF = open(new_file_name, 'wt')
                outF.write( inF.read() )
                inF.close()
                outF.close()
                
            if discard_originals:
                os.remove(file_name)
            
            #put the bin name and the file into a dict
            dir_bins[bin_num] = new_file_name
            
    return dir_bins



def fastq_trimmer(input_filename, output_filename, left_offset = 20, right_offset = 10, 
                  percent_offsets = 'offsets_absolute', 
                  input_type = 'sanger', 
                  keep_zero_length = 'exclude_zero_length', 
                  run_through_command_line = True):
    
    '''performs fastq trimming of a file
    
    $ fastx_trimmer -h
    usage: fastx_trimmer [-h] [-f N] [-l N] [-z] [-v] [-i INFILE] [-o OUTFILE]

    version 0.0.6
       [-h]         = This helpful help screen.
       [-f N]       = First base to keep. Default is 1 (=first base).
       [-l N]       = Last base to keep. Default is entire read.
       [-z]         = Compress output with GZIP.
       [-i INFILE]  = FASTA/Q input file. default is STDIN.
       [-o OUTFILE] = FASTA/Q output file. default is STDOUT.
    
    '''
    fastqtool_dir = config.get("paths", "toolfastq")
    if run_through_command_line:
        command_string = "python3 " + fastqtool_dir + "/fastq_trimmer.py '%s' '%s' '%d' '%d' 'offsets_absolute' 'sanger' 'exclude_zero_length'" % (
                                                                                            input_filename, output_filename, left_offset, right_offset)
        print (command_string)
        os.system(command_string)
    else:       
        out = fastqWriter( open( output_filename, 'wt' ), format = input_type )
        num_reads_excluded = 0
        num_reads = None
        for num_reads, fastq_read in enumerate( fastqReader( open( input_filename ), format = input_type ) ):
            if percent_offsets:
                left_column_offset = int( round( float( left_offset ) / 100.0 * float( len( fastq_read ) ) ) )
                right_column_offset = int( round( float( right_offset ) / 100.0 * float( len( fastq_read ) ) ) )
            else:
                left_column_offset = int( left_offset )
                right_column_offset = int( right_offset )
            if right_column_offset > 0:
                right_column_offset = -right_column_offset
            else:
                right_column_offset = None
            fastq_read = fastq_read.slice( left_column_offset, right_column_offset )
            if keep_zero_length or len( fastq_read ):
                out.write( fastq_read )
            else:
                num_reads_excluded += 1
        out.close()
        if num_reads is None:
            print("No valid fastq reads could be processed.")
        else:
            print("%i fastq reads were processed." % ( num_reads + 1 ))
        if num_reads_excluded:
            print("%i reads of zero length were excluded from the output." % num_reads_excluded)
        
def fastq_trimmer_by_quality(input_filename, output_filename, file_type = "sanger", window = 10, step = 3, ends = 53, action = "min", exclude = 0, criterion = ">=", quality = 20):    
    '''
    Executes this
    python /home/ngsuziv/galaxy-dist/tools/fastq/fastq_trimmer_by_quality.py 
    '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1577.dat' 
    '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1592.dat' 
    -f 'sanger' -s '10' -t '3' -e '53' -a 'min' -x '0' -c '>=' -q '20.0' '''
    
    fastqtool_dir = config.get("paths", "toolfastq") 
    command_string  = "python3 " + fastqtool_dir + "/fastq_trimmer_by_quality.py "
    command_string += "'%s' '%s' -f '%s' -s '%s' -t '%s' -e '%s' -a '%s' -x '%s' -c '%s' -q '%f' " % (
            input_filename, output_filename, file_type, window, step, ends, action, exclude, criterion, quality )
    print("COMMAND: ", command_string)
    os.system(command_string)
    
def filter_fastq(input_filename, output_filename, input_type = 'sanger'):
    ''' launches a function to each read '''
    
    from galaxy_utils.sequence.fastq import fastqReader, fastqWriter
 
    out = fastqWriter( open( output_filename, 'wt' ), format = input_type )    
    i = None
    reads_kept = 0
    
    for i, fastq_read in enumerate( fastqReader( open( input_filename ), format = input_type ) ):
        if fastq_read_pass_filter( fastq_read ):
            out.write( fastq_read )
            reads_kept += 1
    out.close()
    
    if i is None:
        print("Your file contains no valid fastq reads.")
    else:
        print('Kept %s of %s reads (%.2f%%).' % ( reads_kept, i + 1, float( reads_kept ) / float( i + 1 ) * 100.0 ) )
        
    
    
def fastq_read_pass_filter( fastq_read ):
    '''serves as a criterion for every read in the filter'''
    def mean( score_list ):
        return float( sum( score_list ) ) / float( len( score_list ) )
    if len( fastq_read ) < 50:
        return False

    num_deviates = 0
    qual_scores = fastq_read.get_decimal_quality_scores()
    for qual_score in qual_scores:
        if qual_score < 14.0:
            if num_deviates == 0:
                return False
            else:
                num_deviates -= 1
    qual_scores_split = [ qual_scores ]
    return True
    
def remove_sequencing_artifact(input_filename, output_filename):
    """runs
    cat '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1596.dat' | fastx_artifacts_filter  -Q 33  -v -o '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1597.dat'
    """
    
    command_string = "cat '%s' | fastx_artifacts_filter  -Q 33  -v -o '%s'" % (input_filename, output_filename )
    print("COMMAND: ", command_string)
    os.system(command_string)
    
 
    
def interlacer(fn_reads1, fn_reads2, fn_pairs, fn_singles):
    '''runs
    python /home/ngsuziv/galaxy-dist/tools/fastq/fastq_paired_end_interlacer.py '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1598.dat' 'sanger' '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1597.dat' 'sanger' '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1599.dat' '/home/ngsuziv/galaxy-dist/database/files/001/dataset_1600.dat'    
    '''
    fastqtool_dir = config.get("paths", "toolfastq") 
    command_string = "python3 " + fastqtool_dir + "/fastq_paired_end_interlacer.py '%s' 'sanger' '%s' 'sanger' '%s' '%s'" %(
                                         fn_reads1, fn_reads2, fn_pairs, fn_singles                       )
    print("COMMAND: ", command_string)
    os.system(command_string)
    
#------------------------------------------------------------------------
        

def process_paired(bin_dir, pair1, pair2):
    '''in case it is gz, then do gunzip, bin is more project dir'''
    assert os.path.isdir(bin_dir), "The bin directory does not exist: " + bin_dir
    
def process_bin(bin_dir, wanted_bin_num):
    '''takes care of one bin'''
    
    assert os.path.isdir(bin_dir), "The bin directory does not exist: " + bin_dir
    print("Processing bin") 
    #identify the forward and reverse files. 
    os.chdir(bin_dir)
    file_names = [ f for f in listdir(bin_dir) if isfile(os.path.join(bin_dir,f)) ]
    print(file_names)
    
    temp_dir = os.path.join(bin_dir, "temp")
    if not os.path.isdir(temp_dir):
        os.mkdir(temp_dir)
    
    
    fn_fastq1 = None
    fn_fastq2 = None
       
    for file_name in list(file_names):
        if (file_name[-3:len(file_name)] == ".gz"):
            print ("gunzip ", file_name)
            os.system("gunzip -c " + file_name + " > " + bin_dir + "/" + file_name[:-3])
            file_name = file_name[:-3]
            #sys.exit()
        pattern = r"^bin(\d+)_S(\d+)_L001_R(\d+)_001\.fastq\s*$"
        result = re.search(pattern, file_name)
        if result:
            bin_num         = result.group(1)
            s_num           = result.group(2)
            read_direction  = result.group(3)
            print(bin_num, s_num, read_direction)
            #linec = commands.getoutput('wc -l ' + bin_dir + "/" + file_name)
            #print (linec/4) 
            if int(bin_num) == wanted_bin_num:
                if int(read_direction) == 1:
                    if not fn_fastq1 is None:
                        raise ValueError("There are two files of the direction %s for bin %s" % (read_direction, bin_num))
                    else: 
                        fn_fastq1 = file_name
                if int(read_direction) == 2:
                    if not fn_fastq2 is None:
                        raise ValueError("There are two files of the direction %s for bin %s" % (read_direction, bin_num))
                    else: 
                        fn_fastq2 = file_name
                
    
    print("dir 1 fastq '%s'" %fn_fastq1)
    print("dir 2 fastq '%s'" %fn_fastq2)
            
    assert not fn_fastq1 is None, ("No fastq file for direction 1 in bin ")
    assert not fn_fastq1 is None, ("No fastq file for direction 2 in bin ")
    
    print("Will process files:\n%s\n%s" % (fn_fastq1, fn_fastq2))
    
    A1 = os.path.join(temp_dir, "fn_tmp1_A")
    A2 = os.path.join(temp_dir, "fn_tmp2_A")
    print("Trimming ends")
    fastq_trimmer(input_filename=fn_fastq1, output_filename=A1 )
    fastq_trimmer(input_filename=fn_fastq2, output_filename=A2 )

    B1 = os.path.join(temp_dir, "fn_tmp1_B")
    B2 = os.path.join(temp_dir, "fn_tmp2_B")
    print("Trimming with sliding window")
    fastq_trimmer_by_quality(input_filename=A1 , output_filename=B1 )
    fastq_trimmer_by_quality(input_filename=A2 , output_filename=B2 )
    
    C1 = os.path.join(temp_dir, "fn_tmp1_C")
    C2 = os.path.join(temp_dir, "fn_tmp2_C")
    print("Filtering short and low quality reads, stored metrics in db for samples")
    filter_fastq(input_filename=B1 , output_filename=C1 )
    filter_fastq(input_filename=B2 , output_filename=C2 )
    
    D1 = os.path.join(temp_dir, "fn_tmp1_D")
    D2 = os.path.join(temp_dir, "fn_tmp2_D")
    print("Removing artifacts")
    remove_sequencing_artifact(input_filename=C1 , output_filename=D1 )
    remove_sequencing_artifact(input_filename=C2 , output_filename=D2 )
    
    fn_pairs      = os.path.join(bin_dir, "bin%02d_interlacer_pairs.fastqsanger"   % wanted_bin_num)
    fn_singletons = os.path.join(bin_dir, "bin%02d_interlacer_singles.fastqsanger" % wanted_bin_num)
    print("Interlacing the reads")
    interlacer(D1 , D2, fn_pairs, fn_singletons )
    
    #UNCOMMENT WHEN IT WORKS
    shutil.rmtree(temp_dir, ignore_errors = True)
    return


def velvk(datadir, pairfile, singlefile):
    pairsfile   = pairfile#os.path.join(bin_dir, "bin%02d_interlacer_pairs.fastqsanger" % binnum)
    singlesfile = singlefile#os.path.join(bin_dir, "bin%02d_interlacer_singles.fastqsanger" % binnum)
    kmer = config.get('ref_bin_exec', 'kmer')
    velvetdir = "velvet" #+ kmer
    velvetdir = os.path.join(datadir, velvetdir)
    if not(os.path.exists(velvetdir)):
        os.mkdir(velvetdir)
    #run velveth
    velveth_command = "velveth %s %s -fastq -shortPaired %s -short %s" % (velvetdir, kmer, pairsfile, singlesfile)

    print(velveth_command)
    os.system(velveth_command)

    velvetg_command = "velvetg %s -exp_cov 50 -ins_length 300 -cov_cutoff 5 -min_contig_lgth 150 -unused_reads yes -amos_file yes" % velvetdir
    velvetg_command = "velvetg %s -exp_cov 50 -ins_length 300 -cov_cutoff 5 -min_contig_lgth 150 -unused_reads yes -amos_file yes" % velvetdir
    print(velvetg_command)
    os.system(velvetg_command)
    print("velvetg completed")
    
#----------------------------MAIN_SCREEN-------------------------------------
if __name__ == '__main__':
    '''
    '''    
    base_dir = "/media/sf_ngs_data/ngs_virome/virome_07_dipp73-96"
    base_dir = config.get("paths", "ngsdata")
    #runs this only once, if the files have not been unpacked before
    #base_dir = "/home/lljali/ngs_data/ngs_virome/test_data"
    print (base_dir)
    #dir_bins = process_original_files(base_dir = base_dir, prefix = "DIPP")
   
    if (len(sys.argv) != 2):
        print("Invoke automated_run_filtering_galaxy.py with bins/bin_range, ensure that these bings are in ngsdata path")
        print("Range Example:\n python automated_run_filtering_galaxy.py 45-48 runs Branch_A for bins 45,46,47\n")
        print("Bins:\n python automated_run_filtering_galaxy.py 45,47 runs Branch_A for bins 45,47")
        sys.exit()

    
    brange = sys.argv[1]    
    print( "start filtering sample bins " + brange + " " + time.asctime( time.localtime(time.time()) ))
    if (brange.find("-") != -1):
        startrange = int(brange.split("-")[0])
        endrange = int(brange.split("-")[1])  
    
        for bin_num in range(startrange, endrange):
            bin_dir = os.path.join(base_dir, "data", "bin%02d" % bin_num)
            process_bin(bin_dir, bin_num)
            script_for_velvet.assemble_bin(bin_num, bin_dir)
    
    elif (brange.find(",") != -1):
        rangelist = brange.split(",") 
        for bn in rangelist:
            bin_num = int(bn)
            bin_dir = os.path.join(base_dir, "data", "bin%02d" % bin_num)
            process_bin(bin_dir, bin_num)
            script_for_velvet.assemble_bin(bin_num, bin_dir)
    else:
        #bin_num
        #bin_dir = os.path.join(base_dir, "malawi", "" % "processing")
        #process_bin(bin_dir, "")
        #process_bin(bin_dir, bin_num)
        study_dir = "/data/virology/ngs_virome/ngs_data/malawi"
        interlaced_dir = "interlaced"         
        paired_fq = "bin01_interlacer_pairs.fastqsanger"
        single_fq = "bin01_interlacer_singles.fastqsanger"
        pair_fn = study_dir + "/" + interlaced_dir + "/" + paired_fq
        single_fn = study_dir + "/" + interlaced_dir + "/" + single_fq
             
        velvk(study_dir, pair_fn, single_fn)
        #can we produce all_reads at the same time NgsDirs.get_fn_all_reads
    print( "finished filtering " + brange + " " + time.asctime( time.localtime(time.time()) ))
    

