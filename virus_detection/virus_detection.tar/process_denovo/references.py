#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The references class. Utilized in the analysis of viromes. Provides the other programs with sequences of reference viruses
This is a class of reference genbank files (reference sequences).
It collaborates with a directory where these files are stored locally
and enables remote download from the genbank. It is saved after being obtained.
"""
#---IMPORTS-----------------------------------------------------------------------------
import os.path
from os import listdir
from os.path import isfile, join
import io
import time
import sys
import pickle
import random

import xlsxwriter

import Bio
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC
from Bio import Entrez
Entrez.email = 'Ondrej.Cinek@gmail.com'

import re

from Bio import SeqIO
#from Bio import AlignIO
#from Bio import Align

from Bio.Blast import NCBIXML
from urllib.error import URLError

blast_dir = "C:/blast/blast-2.2.28+"
blast_bin_dir = "C:/blast/blast-2.2.28+/bin"
ngs_data_dir = ("E:/ngs_data")
blast_dir = "/data/virology/tools/blast"#C:/blast/blast-2.2.28+"
blast_bin_dir = "/data/virology/tools/blast/bin"#C:/blast/blast-2.2.28+/bin"
ngs_data_dir = ("/data/virology/ngs_virome/ngs_data")#("E:/ngs_data")
if not (os.path.exists(ngs_data_dir) and os.path.isdir(ngs_data_dir)):
    raise ValueError("No directory with NGS data")

class References:
    '''
    This is a class of reference genbank files (reference sequences).
    It collaborates with a directory where these files are stored locally
    and enables remote download from the genbank. It is saved after being obtained.

    '''
    def __init__(self,
                 directory = os.path.join(ngs_data_dir, "references"),
                 blast_dir = "C:/blast/blast-2.2.28+",
                 blast_bin_dir = "C:/blast/blast-2.2.28+/bin" ):
        '''The directory where the reference genbank files are stored
        The path to local blast executable, and to binaries where the databases reside
        AUTOMATICALLY LOADS THE IDENTITY TABLE if such table exists!

        '''
        self.directory = directory
        self.pickle_filename = os.path.join(self.directory, "_references_identity_table.pickle")
        print(self.pickle_filename)
        self._identity_table = {} #empty identity table
            #has the structure of {(accession number, accession number):{parameters of blast query}}
        self._todays_accessions = set()  #the accession numbers seen today
        self._todays_sequences = {}  #a dict of accession:seqrecord seen today - for short-term retrieval from memory
        self.blast_bin_dir = blast_bin_dir
        self.blast_dir = blast_dir
        self.warnings = []
        self._identity_table_loaded = False
        self._load_identity_table()

        return


    def _load_identity_table(self):
        '''
        This loads the identity table from a pickled file. For 500 references, all mutual combinations had
        only 4 MB, so it is much memory-effective to keep the table this way.
        '''
        #is there a file with pickled identity table?
        if os.path.isfile(self.pickle_filename):
            #if yes, let us unpickle it.
            fh_pickle = None
            try:
                fh_pickle = open(self.
                                 pickle_filename, mode = "rb") #read binary open
                self._identity_table = pickle.load(fh_pickle) #unpicle, load the variable
                self._identity_table_loaded = True
                #print("\n\n",self._identity_table)
            except (EnvironmentError, pickle.UnpicklingError) as err:
                print("error when loading the identitiy table: %s", err)
            finally:
                if fh_pickle is not None:
                    fh_pickle.close()
        else:
            print("Warning - no identitity table found")
        return


    def _save_identity_table(self):
        '''
        The table of identity between reference sequences has to be saved after any changes
        This subroutine pickles the identity table'''

        fh_pickle = None
        try:
            fh_pickle = open(self.pickle_filename, mode = "wb") #write binary open
            pickle.dump(self._identity_table, fh_pickle, protocol= pickle.HIGHEST_PROTOCOL) #pickle, save the variable
            self._identity_table_loaded = True
        except (EnvironmentError, pickle.PickleError) as err:
            print("error when saving the identitiy table: %s", err)
        finally:
            if fh_pickle is not None:
                fh_pickle.close()
        return

    def has_identity_table(self):
        return self._identity_table_loaded

    def get(self, accession):
        #TODO: bacha nefunguje, když accession neexistuje!
        '''
        Returns the seqrecord object of the given accession number.
        It is first sought for in the memory, then on the disk, and finally on the Internet.
        Any retrieved sequence is then permanently stored
        '''
 
        if accession in self._todays_sequences:
            return self._todays_sequences[accession]
        else:
            ref_seqrecord = []
            filename = os.path.normpath(self.directory + '/' + accession + '.gb')
            if os.path.isfile(filename):
                #the file already exists - we will just create the record and return it
                ref_seqrecord = SeqIO.read(filename, "genbank")
            else:
                #the file does not exist - we will download the record, write it to disk, and
                #then return it.
               
                #find the number of hits - first run the query with a low retmax (default to 20)
                #this is only for finding how many the total number is
                handle = Entrez.esearch(db = "nucleotide", term = accession, retmax = 20)
                record = Entrez.read(handle)
                total_hits = int(record["Count"])
                print("retrieving accession", accession, handle)
                if total_hits == 1:
                    ##and now we will actually fetch the gi's - fetch all values:
                    #handle = Entrez.esearch(db = "nucleotide", term = accession, retmax = total_hits)
                    #record = Entrez.read(handle)
                    #id_list = record["IdList"]

                    handle = Entrez.efetch(db="nucleotide",
                                           id=accession,
                                           rettype="gb",
                                           retmode="text")
                    ref_seqrecord = SeqIO.read(handle, "genbank")
                    SeqIO.write(ref_seqrecord, filename, "genbank")

                elif total_hits > 1:
                    #check with Ondrej, return ref_seqrecord anyway
                    self.warnings.append("More than one record from BLAST of %s: %s (max 20)" % (accession, total_hits))
                else:
                    #insert this accession into db report
                    self.warnings.append("cannot find %s in the NCBI Entrez db. Most likely you wanted to supply your own reference." % accession)

            #adds to the references utilized today
            self._todays_accessions.add(accession)
            self._todays_sequences[accession] = ref_seqrecord            
            return ref_seqrecord


    def feed_in_contigs_as_references(self, fasta_file, run = "", project = ""):
        '''Feeds into the references object a private list of fasta sequences generated locally.
        These references are contigs arising from previous de novo assembly.

        The names are forged from the node number'''

        for new_seqrecord in Bio.SeqIO.parse(fasta_file, "fasta"):
            result = re.search(r"NODE_(\d+)_bin(\d+)_length_(\d+)_cov_(\d+)", new_seqrecord.name, re.I)
            if result:
                #get the characteristics of the contig
                contig_no = int(result.group(1))
                bin_num_imported = int(result.group(2))
                length   = int(result.group(3))
                coverage = int(result.group(4))

                new_seqrecord.seq.alphabet = IUPAC.ambiguous_dna
                new_seqrecord.name = "B%04dN%07d" % (bin_num_imported, contig_no)
                new_seqrecord.accession = new_seqrecord.name
                new_seqrecord.definition = ("a reference sequence made of contig %s from run %s, project %s"
                    % (new_seqrecord.name, run, project) )
                new_seqrecord.version = 1

                filename = os.path.join(self.directory, new_seqrecord.name + '.gb')
                SeqIO.write(new_seqrecord, filename, "genbank")

                self._todays_accessions.add(new_seqrecord.accession)
                self._todays_sequences[new_seqrecord.name] = new_seqrecord
            else:
                raise ValueError("invalid contig name at import: %s" % new_seqrecord.id)

        return


    def check_identity_scores(self, accession):
        '''
        This should check wheteher we know identity scores of the accession number to all other
        that have been requested in the present session. If not, recalculate, and update the pickled
        file
        '''

        #first, add the presently requested accession to today's repertoire.
        self._todays_accessions.add(accession)
        this_seqrecord  = self.get(accession)

        #for each of today's accessions, do we know the identity?
        #make a difference set that will not include the present accession
        other_accessions = self._todays_accessions.difference(set(accession))
        #flag that all identity scores are known as an initial value.
        any_new_info = False

        for other in other_accessions:
            if (accession, other) in self._identity_table:
                continue
            else:
                #and if not, what is the identity, please calculate, and leave a flag
                any_new_info = True
                other_seqrecord = self.get(other)
                self._identity_table[(accession, other)] = similarity_blast(this_seqrecord, other_seqrecord)

        #is the flag on? Has anything been added? if so, save it
        if any_new_info:
            self._save_identity_table()
        return

    def export_pairwise_identity_table(self,
                                       excel_fn,
                                       accessions,
                                       contents = (
                                        #'bitscore',
                                        #'score',
                                        #'e',
                                        'percent_identity',
                                        'total_alignments_length',
                                        #'total_identical_bases'
                                        ),
                                       ):
        '''
        Prints a pairwise identity table of the requested
            excel_fn = filename incl path of the target excel file
            [content = a tuple with requested names of the content]
            *accessions = accession names
        '''

        if len(accessions) == 0:
            accessions = list(self._todays_accessions)
        else:
            self._todays_accessions.update(set(accessions))

        excel_fn = os.path.normpath(excel_fn)
        workbook = xlsxwriter.Workbook(excel_fn)
        worksheet = workbook.add_worksheet("pairwise identity")
        worksheet.fit_to_pages(1,1) #fit to one page
        worksheet.set_paper(9) #A4
        worksheet.set_landscape()
        worksheet.hide_gridlines(0)

        fmt_rotated_bold        = workbook.add_format({'bold': True, 'font_name':'Calibri','font_size':11,
                                        'rotation':90, 'valign':'bottom', 'align':'center'})
        fmt_rotated_normal      = workbook.add_format({'bold': False, 'font_name':'Calibri','font_size':11,
                                        'rotation':90, 'valign':'bottom', 'align':'center'})
        fmt_row_title_bold      = workbook.add_format({'bold': True, 'font_name':'Calibri','font_size':11,
                                        'align':'left'})
        fmt_row_title_italics   = workbook.add_format({'font_name':'Calibri','font_size':11, 'align':'left', 'italic':True})
        fmt_text    = workbook.add_format({'font_name':'Calibri','font_size':11, 'align':'right'})
        fmt_text_la = workbook.add_format({'font_name':'Calibri','font_size':11, 'align':'left'})

        #fixed texts
        worksheet.write(0,0, "acc numbers", fmt_row_title_bold)
        worksheet.write(0,1, "content", fmt_row_title_bold)
        #column_names col 2 onwards
        for (col, acc) in enumerate(accessions, 2): #from column 2
            worksheet.write(0, col, acc, fmt_rotated_bold)
        #row_names
        for (i, acc) in enumerate(accessions, 0):
            firstrow = 1 + i*len(contents)
            worksheet.write(firstrow,0, acc, fmt_row_title_bold)
            for (k, content) in enumerate(contents):
                worksheet.write(firstrow + k, 1, content, fmt_row_title_italics)

        #content
        for (i, acc_row) in enumerate(accessions, 0):
            print("doing row %s" % i)
            firstrow = 1 + i*len(contents)
            for (j, acc_col) in enumerate(accessions, 0):
                if acc_row == acc_col:
                    for (k, content) in enumerate(contents):
                        worksheet.write(firstrow + k, 2+j, "x" , fmt_text)
                else:
                    id_sc = self.get_identity(acc_row, acc_col)
                    for (k, content) in enumerate(contents):
                        if not isinstance(id_sc, dict):
                            what = "-"
                        else:
                            what = int(id_sc[content]) if content != 'e' else "%.2e" % id_sc[content]
                        worksheet.write(firstrow + k, 2+j, what , fmt_text)
        workbook.close()
        return

    def get_identity(self, this_acc, other_acc):
        '''returns the identity scores for the pair'''

        self._todays_accessions.add(this_acc)
        self._todays_accessions.add(other_acc)

        if this_acc == other_acc:
            raise ValueError("the two accessions are identical - no need to compare the identity")

        #now we will check whether we have the identity table to the others in the session???
        if not (this_acc, other_acc) in self._identity_table:
            self.check_identity_scores(this_acc)
            self.check_identity_scores(other_acc)

        return self._identity_table[(this_acc, other_acc)]

    def get_todays_accessions(self):
        return self._todays_accessions

    #reduction of complexity of a reference list
    def reduce_reference_list(self, reflist, max_length_difference = 250, min_identity_level = 95, xlsx_filename = None):
        '''Reduces a list of accession numbers of reference files, based on their mutual identity.
        Returns a list of replacements.

        reflist = the list of accession names that needs to be reduced
        max_length_difference - how much shorter can a replacement be
        min_identity_level - the minimum identity level of the replacement
        xlsx_filename = the path to an output file where the reduction will be specified
        '''
        #original order of the reference list should be preserved
        original_order = reflist[:]

        #sort reflist by length of the sequence, decreasing.
        reflist = sorted(reflist, key = lambda x: -len(self.get(x)))

        print("Starting the creation of the replacement table")
        self.replacements = {}
        n = len(reflist)
        print("   Original list: %d references, " % n, reflist)
        new_reflist = list(reflist) #copy it...

        for i in range(0, n): #the one higher in the order
            if (reflist[i] == None):
                continue
            acc_i = reflist[i]
            if not acc_i in new_reflist:
                continue #has been already removed
            seq_i = self.get(acc_i)
            print("     ... %d %%" % int(100*i/n))

            for j in range(i+1, n): #the one lower in the order
                acc_j = reflist[j]
                if not acc_j in new_reflist:
                    continue #has been already removed
                seq_j = self.get(acc_j)

                print("comparing %s   to %s" %(acc_i, acc_j))
                identity_dict = self.get_identity(acc_i, acc_j)
                if identity_dict is None or identity_dict == {}:
                    continue #the two are too remote; both will be retained
                total_aln_len = identity_dict['total_alignments_length']
                total_perc_identity = identity_dict['percent_identity']
                #if it is almost identical, and the shortening is not more than the max allowed length
                if total_perc_identity >= min_identity_level and len(seq_i) - len(seq_j) < max_length_difference: #longer minus shorter is less than max difference
                    #replace
                    if acc_j in self.replacements:
                        (replacement, old_score)  = self.replacements[acc_j]
                        if old_score >= total_perc_identity:
                            continue
                    self.replacements[acc_j] = (acc_i, total_perc_identity)
                    new_reflist.remove(acc_j)

        sorted_new_reflist = sorted(new_reflist, key = lambda x: original_order.index(x))

        print("Replacement table created")
        print("   New list: %d references, " % len(sorted_new_reflist), sorted_new_reflist)

        return sorted_new_reflist

#general routines
def delete_temps(*filenames):
    for (fname) in filenames:
        if os.path.exists(fname):
            try:
                os.remove(fname)
            except IOError as e:
                print(e)

def similarity_blast(query_sequence,
                     subject_sequence,
                     temp_directory = "/data/virology/ngs_virome/ngs_data/temp",
                     restriction = None,
                     depth_blast = 10,
                     evalue = 1,
                     ):
    '''
    Obtains a result of a blast query done locally

    Parameters:
    query_sequence = query sequence or a Seq object
    subject_sequence = reference sequence or a Seq object
    temp_directory = address of a temporary dir
    restriction = None,
    depth_blast = 10,
    evalue = 1
    '''

    #put in the temp files
    temp_directory = os.path.normpath(temp_directory)
    if not os.path.exists(temp_directory):
        os.makedirs(temp_directory)
    rand_id = random.randint(1, 100000000000)
    fn_query   = os.path.join(temp_directory, "temp_query_%d.fa" % rand_id)
    fn_subject = os.path.join(temp_directory, "temp_subject_%d.fa"  % rand_id)
    fn_outfile = os.path.join(temp_directory, "temp_outfile_%d.xml" % rand_id)

    fh_query = None
    fh_subject = None
    fh_outfile = None

    fh_query    = open(fn_query, mode="w")
    fh_subject  = open(fn_subject, mode="w")

    #upgrades a str through seq to seqrecord if needed
    if type(query_sequence) is str:
        query_sequence = Seq(query_sequence, alphabet = IUPAC.ambiguous_dna)
    if type(query_sequence) is Seq:
        query_sequence = SeqRecord(seq = query_sequence, id="query")
    SeqIO.write(sequences = query_sequence, handle = fh_query, format = "fasta")
    fh_query.close()

    #upgrades a str through seq to seqrecord if needed
    if type(subject_sequence) is str:
        subject_sequence = Seq(subject_sequence, alphabet = IUPAC.ambiguous_dna)
    if type(subject_sequence) is Seq:
        subject_sequence = SeqRecord(seq = subject_sequence, id="subject")
    SeqIO.write(sequences = subject_sequence, handle = fh_subject, format = "fasta")
    fh_subject.close()

    #Local BLAST query being sent for comparison of two sequences
    blast_cmd_text= ('blastn -task megablast -query %s -subject %s -out %s -outfmt 5 -evalue %f -num_alignments %d'
                    %
                    (
                     fn_query,
                     fn_subject,
                     fn_outfile,
                     evalue,
                     depth_blast,
                     )
                    )
    #perform blastn megablast on the query file ... with output file ... with output format 5 (xml)
    #print("BLAST query: %s" % blast_cmd_text)
    try:
        #perform the command as if it were sent to the "command window"
        os.chdir(blast_bin_dir)
        os.system(blast_cmd_text)
    except Exception as e: #if there is an exception, print it and re-raise
        print(e)
        raise

    score = parse_pairwise_blast_xml(fn_outfile)
    if (score != {}):    
        delete_temps(fn_query, fn_subject, fn_outfile)
    return score


def parse_pairwise_blast_xml(filename,
                             min_percent_length_match = 70,
                             min_percent_identity = 60):
    '''
    Analyzes the output of a pairwise blast with the aim of providing an identity score.
    Returns None if the two sequences are unrelated,
    or a dict containing bitscore, score, percent identity and query length.
    Do not ask me about the difference between bitscore and score...
    '''
    if not (os.path.exists(filename)):
        return {}
    fh = open(filename, mode='r')
    res_iter = NCBIXML.parse( fh )
    results  = list(res_iter)
    fh.close()

    if len(results) == 0:
        return None
    elif len(results) > 1:
        raise ValueError("this is probably not a pairwise Blast result - more than one Blast record")
    else:
        blast_record = results[0]
        if len(blast_record.alignments) > 1:
            raise ValueError("this is probably not a pairwise Blast result - more than one Blast alignment")
        elif len(blast_record.alignments) == 0:
            return None
        else:
            #calculate the total percent identity of the alignment
            aln = blast_record.alignments[0]
            total_identities = 0
            total_align_length = 0
            for hsp in aln.hsps:
                total_align_length  += hsp.align_length
                total_identities    += hsp.identities
            total_percent_identity = 100*total_identities / total_align_length

            descr = blast_record.descriptions[0]
            return {
                    "bitscore":                     descr.bits,
                    "score":                        descr.score,
                    "percent_identity":             total_percent_identity,
                    "num_alignments":               descr.num_alignments,
                    "e":                            descr.e,
                    "total_alignments_length":      total_align_length,
                    "total_identical_bases":        total_identities,
                    }


def define_relatedness_for_a_directory_of_references(directory):
    '''
    defines a table of relatedness in a directory of gb files
    '''

    temp_refs = references()

    filenames = list(os.listdir(directory))
    num_filenames = len(filenames)
    for (i, filename) in enumerate(filenames):
        print("%d of %d files at %s" % (i, num_filenames, time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()) ))
        if filename.endswith(".gb"):
            result = re.search("^(.*)\.gb$", filename, re.IGNORECASE)
            if result:
                accession = result.group(1)
                temp_refs.check_identity_scores(accession)
    return



if __name__ == '__main__':

    ref = references()
    original_reflist = ['KC785531.1', 'KC785532.1', 'DQ995647.1', 'KC785528.1',
                        'JN542510.1', 'KC344833.1', 'KC785530.1', 'KC344834.1',
                        'JX514942.1', 'KC785529.1', 'AF499643.1', 'JX174177.1',
                        'JX174176.1', 'AF499635.1', 'DQ995634.1', 'AY697461.1',
                        'AB192877.1', 'EF015886.1', 'DQ995648.1', 'AY773285.1',
                        'AM040036.1', ]
    reduced = ref.reduce_reference_list(original_reflist)



