            
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Takes a fasta file and sorts the sequences by origin into three categories:
(a) sequences of bacterial ribosomal RNA (utilizes also 5S and 23S databases)
(b) human sequences
(c) other - these include viruses, other DNA than human, and novel organisms

"""

import re
import sys
import os

import shutil
from datetime import date, datetime
from time import gmtime, strftime

import Bio
from Bio.Seq import Seq
from Bio.Sequencing import Ace
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC
from Bio import SeqIO
from  Bio.SearchIO.BlastIO.blast_xml import BlastXmlParser

sys.path.append(r"E:\programs\nextgen\virome\blast_operations")
import blast_operations


    
def divide_mached_and_unmatched(
                                xml_filenames,
                                min_percent_length_match = 80,
                                min_percent_identity = 80
                                ):
    '''Gets the files of one sample, and finds matched or unmatched sequences
    Parameters:
    min_percent_length_match: the query should be aligned to
                no less than e.g. 90% of the hit to exclude short pieces
    min_percent_identity: how close should it be minimally?
    Returns: a list of id s of unmatched sequences
    '''
    unmatched_ids = []
    matched_ids = []

    print("Now extracting matches from %d xml files." % len(xml_filenames))
    counter = 0
    for filename in xml_filenames:
        #open the file and parse the results
        fh = open(filename, mode='r')
        for blast_record in  BlastXmlParser( fh ):
            this_id = blast_record.id
            known_hits_for_this_id = 0

            #print("id>%s< items >%s< hits >%s<"%(blast_record.id, blast_record.items, blast_record.hits))
            #print("   Blast rec: ", blast_record)
            #note that we process ONLY the queries that have given at least one hit!!!!

            for hit in blast_record.hits:
                #filters too short or too long target sequence
                maxscore = 0
                maxhsp = None
                hsps = list(hit.hsps)
                #go through the segments  - which of them has the highest score?
                for hsp in hsps:
                    #is the match long enough and has enough identity? If not, take next
                    if (hsp.aln_span < min_percent_length_match * blast_record.seq_len / 100
                        or
                        100 * hsp.ident_num / hsp.aln_span < min_percent_identity):
                        continue #to next hsp
                    #is it the best match
                    if hsp.bitscore < maxscore:
                        continue #no, it is not...
                    maxscore = hsp.bitscore
                    maxhsp = hsp

                if not maxhsp is None:
                    known_hits_for_this_id += 1

            #print("sequence >%s< had >%d< hits" % (this_id, known_hits_for_this_id))
            if known_hits_for_this_id == 0:
                unmatched_ids.append(this_id)
            else:
                matched_ids.append(this_id)
        fh.close()
        counter += 1
        print(" ... done %d of %d" % (counter, len(xml_filenames)))

    return {"matched": matched_ids, "unmatched":unmatched_ids}


def divide_fasta_file(fn_source, fn_of_matching , fn_of_unmatching , list_of_ids ):
    '''takes a fasta file, two file names (matching and unmatching reads), and a list of keys
    divides the fasta file into two'''


    matching_handle = open(fn_of_matching, mode = "w")
    un_matching_handle = open(fn_of_unmatching, mode = "w")

    for record in SeqIO.parse(fn_source, format = "fasta", alphabet = IUPAC.ambiguous_dna ):
        if record.id in list_of_ids:
            fasta_out_handle = matching_handle
        else:
            fasta_out_handle = un_matching_handle

        #print all nucleotide sequences as fasta
        print(">%s" % record.id, file = fasta_out_handle)
        print("%s" % record.seq, file = fasta_out_handle)


    matching_handle.close()
    un_matching_handle.close()

    return




def blast_and_divide(input_file, write_protocol = False, protocol_file = None, append_to_protocol = False):
    '''Runs blast queries for all items in the file, and
    divides the items into groups of human, bacterial ribosomal, and other sequences

    parameters:
        input_file = full path to the file with fasta sequences
        write_protocol = whether a protocol has to be written on the process (gives counts of sequences in category
        protocol_file = path to protocol file. If none, a txt protocol will be created in the same directory with results
        append_to_protocol = append? (true) or make a new protocol'''

    #the result - count of bacterial, human and non-bacterial non human sequences
    count_of_items = {}

    input_file = os.path.abspath(input_file)
    directory, input_filename = os.path.split(input_file)
    input_core_name, extension = os.path.splitext(input_filename)
    temp_dir = os.path.join(directory, "temporary")
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)

    #removal of bacterial ribosomal sequences
    batches_bacterial_ribosomes =  blast_operations.split_and_blast(outputdir = temp_dir, list_files = [input_file],
                    restriction = "ribosomes",
                    local_execution = True,
                    depth_blast = 5,
                    evalue = 0.001, nmaxseq = 5000, delete_blast_xml = False,
                    num_processes = 3, num_threads = 3,
                    remove_garbage = False, algorithm = "megablast")
    dict_matched_unmatched_bacterial = divide_mached_and_unmatched(batches_bacterial_ribosomes.keys() )

    count_of_items["bacterial_ribosomal"] = len(dict_matched_unmatched_bacterial["matched"])

    fn_bacterial = os.path.join(directory, input_core_name + "_bacterial" + extension )
    fn_non_bacterial = os.path.join(directory, input_core_name + "_non_bacterial" + extension )
    divide_fasta_file(fn_source = input_file,
                      fn_of_matching = fn_bacterial,
                      fn_of_unmatching = fn_non_bacterial,
                      list_of_ids = dict_matched_unmatched_bacterial['matched']
                      )

    #removal of human sequences
    batches_human =  blast_operations.split_and_blast(outputdir = temp_dir, list_files = [fn_non_bacterial],
                    restriction = "human",
                    local_execution = True,
                    depth_blast = 5,
                    evalue = 0.001, nmaxseq = 5000, delete_blast_xml = False,
                    num_processes = 3, num_threads = 3,
                    remove_garbage = False, algorithm = "megablast")
    dict_matched_unmatched_human = divide_mached_and_unmatched(batches_human.keys() )

    count_of_items["human"] = len(dict_matched_unmatched_human["matched"])
    count_of_items["non_bacterial_ribosomal_non_human"] = len(dict_matched_unmatched_human["unmatched"])

    fn_human = os.path.join(directory, input_core_name + "_human" + extension )
    fn_non_bacterial_non_human = os.path.join(directory, input_core_name + "_non_bacterial_non_human" + extension )
    divide_fasta_file(fn_source = fn_non_bacterial,
                      fn_of_matching = fn_human,
                      fn_of_unmatching = fn_non_bacterial_non_human,
                      list_of_ids = dict_matched_unmatched_human['matched']
                      )

    if write_protocol:
        if protocol_file is None:
            protocol_file = os.path.join(directory, "%s_protocol.txt"%input_core_name)
        mode_opening = "a" if append_to_protocol else "w"
        protocol_handle = open(protocol_file, mode = mode_opening)
        text  = "processed file name:>%s< gave of total of >%d< sequences:" % (input_file, count_of_items["bacterial_ribosomal"] + count_of_items["human"] + count_of_items["non_bacterial_ribosomal_non_human"])
        text += " bacterial ribosomal reads:>%d<" % count_of_items["bacterial_ribosomal"]
        text += ", human sequences >%d<, other non-human non-bacterial >%d<."% (count_of_items["human"], count_of_items["non_bacterial_ribosomal_non_human"])
        print(strftime("%Y-%m-%d %H:%M:%S", gmtime()), text, file = protocol_handle)
        protocol_handle.close()


    shutil.rmtree(temp_dir)

    return count_of_items

if __name__ == '__main__':
    input_file = "test_data/test_contigs.fa"
    input_file = "test_data/test_all_reads.fa"
    result = blast_and_divide(input_file, write_protocol = True)
    print(result)


           
        
        
        
        
        
        