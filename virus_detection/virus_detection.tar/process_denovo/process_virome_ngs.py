#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
This script starts with Velvet assemblies and singletons, and finds the best matches
these are then further processed.
"""
#---IMPORTS-----------------------------------------------------------------------------
import tkinter as tk
from tkinter import messagebox
import re
from tkinter.filedialog import *
from tkinter import ttk
from tkinter.ttk import Combobox

import os.path
from os import listdir
from os.path import isfile, join
import io
import time
import datetime
import sys
import pickle
import shutil

import pickle

import Bio
from Bio.Seq import Seq
from Bio.Sequencing import Ace
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC
from Bio import Entrez
Entrez.email = 'Ondrej.Cinek@gmail.com'

from Bio import SeqIO
from Bio import AlignIO
from Bio import Align

from Bio.Blast import NCBIXML
from urllib.error import URLError

from Bio import pairwise2
from Bio import Phylo   #for the trees of references

import xlsxwriter
import threading
import queue

import references
import sam_file_operations
import tabmatch

#sys.path.append(r"E:\programs\nextgen\virome\blast_operations")
#sys.path.append(r"c:\programs\nextgen\virome\blast_operations")
sys.path.append("/var/www/cgi-bin/virp/scripts/blast_operations")
import blast_operations
#sys.path.append(r"E:\programs\nextgen\virome")
from NgsDirs import NgsDirs



#---------------------- global vars -----------------------------

#nmaxseq = 5000 #max number of sequences in a batch


#Stores: keys = input (xml) filenames, values = input fasta filenames.

#the problem with two computers - either on E , or on C
ngs_data_dirs = ("/data/virology/ngs_virome/ngs_data/")#E:/ngs_data", "C:/ngs_data")
for ngs_data_dir in ngs_data_dirs:
    if os.path.exists(ngs_data_dir) and os.path.isdir(ngs_data_dir):
        break
else: #executed after "for" terminates normally, i.e. not by break
    raise Exception("No directory with NGS data")


#default starting directory
ngs_data_dir = "/data/virology/ngs_virome/ngs_data"
BASEDIR =os.path.join(ngs_data_dir,'ngs_virome')

#REFDIR = os.path.join(BASEDIR, "references")
refs = references.References()
#refs = references.References(REFDIR)

#DIR_EXT_VELVET = "velvet"
#DIR_EXT_SEQUENCHER = "sequencher"

DIR_EXT_BLAST = "blast"
DIR_EXT_TBLASTX = "tblastx"

BLAST_DIR       = ""
BLAST_BIN_DIR   = ""

sel_databases   = ["all_viruses", "picornaviridae" , "enterovirus" ]
sel_iteration   = ["automatic", "manual" ]
sel_depth_blast = [1000, 100, 10]





#---SUBS--------------------------------------------------------------------------------

#
# def print_seqrecords_as_ungapped_fasta(matching_seqrecords, output_filename, bin_name):
#     '''
#     Prints ungapped fasta list of sequences found to match to the reference
#     a) first, the reference is printed (although with the bin_ prefix)
#     b) then nodes (contigs)
#     c) lastly the singletons that match
#
#     The output is used in the creation of an alignment in Sequencher.
#
#     '''
#
#     output_fa = open(output_filename, mode='w')
#
#     for rec in matching_seqrecords:
#         print((">%s_" % bin_name) + tabmatch.shorten_read_name(rec.id)[0] + " " + rec.id, file = output_fa)
#         strseq = str(rec.seq)
#         print(strseq.replace("-", ""), file = output_fa)
#     output_fa.close()

def insert_a_filename_in_list(lb, set_basedir = False):
    '''Inserts a filename into a listbox with files to be processed.

    lb = the listbox to which a filename is appended
    set_basedir = (False) whether the global variabel basedir should be modified to the value of these files
    '''

    global basedir
    list_fnames = lb.get(0,END)
    filecount = len(list_fnames)
    startdir = '' #where to start with opening the file
    if filecount == 0:
        startdir = os.path.abspath(basedir)
    else:
        startdir = os.path.split(list_fnames[0])[0] #the path of the first file


    try:
        filename = askopenfilename(initialdir = startdir)
        dirname, file_n = os.path.split(filename)
        if dirname != startdir and filecount > 0:
            messagebox.showinfo(
                    message = "All source files should belong to one directory!",
                    type = "ok")
            return
        else:
            lb.insert(END, filename)
    except Exception as e:
        print(e)


    if set_basedir:
        basedir = startdir
    return



def find_best_match(read_files,
                    velvet_output_files,
                    bin_num,
                    ngs_dirs,
                    restriction,
                    iteration = "automatic",
                    depth_blast = 30,
                    algorithm = "megablast"):

    '''Manages the three steps of analysis (finding the best match)

    Parameters:
    read_files = the files with original reads
    velvet_output_files = the contigs, and UnusedReads files
    bin_name = name of the bin to be used in filename construction
    bin_dir = similarly
    iteration = "automatic" (default), "manual" - supervised
    restriction = what BLAST database should be utilized "all_viruses", "picornaviruses", "nt" etc...
    algorithm = "megablast" (default) or "tblastx"; algorithm for BLAST

    Output: a file where the reference is the first, and the matched contings and reads follow
    can be then utilized in the Sequencher
    '''

    bin_name = ngs_dirs.get_bin_name(bin_num)
    bin_dir  = ngs_dirs.get_bin_dir(bin_num)
    fn_all_velvet_sequences  = os.path.join(bin_dir, "%s_all_velvet_sequences.pickle" %(bin_name))

    tab = tabmatch.Tabmatch(refs, bin_name = bin_name, bin_dir = bin_dir)
    all_velvet_sequences = None
    #do we have the velvet sequences stored from a previous run?
    if (os.path.exists(fn_all_velvet_sequences) and os.path.isfile(fn_all_velvet_sequences)):
        print(".... loading the pickled sequences from Velvet")
        handle_all_velvet_sequences = open(fn_all_velvet_sequences, mode = "rb")
        all_velvet_sequences = pickle.load(handle_all_velvet_sequences)
        handle_all_velvet_sequences.close()

    blast_dir = ngs_dirs.get_blast_dir(bin_num, algorithm, restriction)
    fn_tab_matches_initial = os.path.join(blast_dir, "%s_initial_table_algorithm_%s_restriction_%s.pickle"
                                  % (bin_name, algorithm, restriction) )
    fn_tab_matches_final = os.path.join(blast_dir, "%s_last_results_match_of_%s_to_%s.pickle"
                                  % (bin_name, algorithm, restriction) )

    if not (algorithm ==  "tblastx" or algorithm == "megablast"):
        raise NotImplementedError("algorithm " + algorithm + " is not implemented")


    if (os.path.exists(fn_tab_matches_final) and os.path.isfile(fn_tab_matches_final)):
        print("it seems that this part of the analysis has been done previously. If you disagree with its results and want to run it again,")
        print("please delete the whole content of the directory '%s' and re-run the script" % blast_dir)
        return

    #the analysis has not been finished
    #We will first get the tabmatch table with blast results.
    #have the matches been already extracted?
    print("Have the BLAST matches been already done and extracted from xml files?", fn_tab_matches_initial)

    #TODO: this is useless, if there is the final table available, no need to retain the initial one!!!!
    if (os.path.exists(fn_tab_matches_initial) and os.path.isfile(fn_tab_matches_initial)):
        print(".... YES - loading the pickled table of matches")
        tab.load(fn_tab_matches_initial)
    else:
        print(".... NO - will split the fasta file, Blast it and make the table of matches")
        #first split the files into batches, then blast them, and finally process the files into one tabmatch file
        batches = dict()
        all_velvet_sequences = dict()
        print( "\n----------------------------\nFile splitting started...\n---------------------------\n" )
        #first split the files whose names are in the listbox_fastq,
        temp_files1 = blast_operations.split_sequences_into_batches(
                                    all_velvet_sequences,
                                    batches,                #an empty dict
                                    outputdir = blast_dir,
                                    list_fnames = velvet_output_files
                                    )
        #ends up with the chunks of fasta files, and full dict of "batches"
        tab.temporary_files.update(temp_files1)

        #then run their blast
        print("\n------------------------\nStarting the multithreaded BLAST...\n-------------------------")
        blast_operations.multithreaded_blast(batches,
                            restriction = restriction,
                            depth_blast = depth_blast,
                            algorithm = algorithm)

        #compute a table of best matches
        print("\n------------------------\nComputing scores for the best matches, extracting...\n-------------------------")
        xml_filenames_to_process = list(batches.keys())
        batches.clear()

        #creates a new object of a table with BLAST matches.
        tab.extract_matches_from_xml( #take only matches to references between the limits (bases)
                                    min_length_subject = 1000, #HERE was a problem with small viruses
                                    max_length_subject = 500000,
                                    min_percent_length_match = 90, #aligned to no less than 90% of the hit
                                    min_percent_identity = 60 , #minimum identity
                                    xml_filenames = xml_filenames_to_process
                                 )
        tab.temporary_files.update(xml_filenames_to_process) #adds these for later cleanup

        print("Saving the products of this analysis")
        #saving #1
        tab.save(fn_tab_matches_initial)
        #saving #2
        handle_all_velvet_sequences = open(fn_all_velvet_sequences, mode = "wb") #write binary open
        pickle.dump(all_velvet_sequences, handle_all_velvet_sequences, protocol= pickle.HIGHEST_PROTOCOL)
        handle_all_velvet_sequences.close()

    #and now process the table of matches to reduce the complexity - the iterations.
    try:
        print("determining the winner reference sequences algo", algorithm)
        tab.process_match_table(all_sequences  =  all_velvet_sequences,
                                algorithm = algorithm,
                                was_blasted_to = restriction
                                )
        #why is this necessary?
        #sam_dir = ngs_dirs.get_sam_dir(bin_num, algorithm, restriction)
        #if not os.path.exists(sam_dir):
        #    os.mkdir(sam_dir)
        fn_winners = ngs_dirs.get_fn_winner_accessions(bin_num, algorithm, restriction)
        print("fn winners", fn_winners)
        handle_winners = open(fn_winners, mode = "w")
        #why check tab.get_winner_accessions and not handle_winners?
        print("tab.get_winner_accessions() ", tab.get_winner_accessions() )
        for i in tab.get_winner_accessions():
            #print(i)
            print(i, file = handle_winners)
        print("", file = handle_winners)
        handle_winners.close()


    except Exception as e:
        print(e)
        raise

    finally:
        #print("FINAL CLEANUP")
        #tab.cleanup()
        print("NOT CLEANED ANALYSIS FINISHED for bin %s" % bin_name)

    #the resulting data are in the directories.
    return


#----------------------------MAIN_SCREEN-------------------------------------
def main_screen():
    '''
    main_screen  ... GUI
    ->find_best_match ... gets all reads, the assembled reads, bin_name, and parameters for BLAST
      ->split_sequences_into_batches (fastq files) - makes chunks can be handled by BLAST
      ->multithreaded_blast ... performs blast on the chunks of sequences (batches)
      tab = tabmatch ... local in this process
      ->process_bin ... makes the bamatch table, and gradually processes it
      ->tab.bwa_of_simplified_reflist ... makes sam files
    '''

    root = tk.Tk() #the main screen
    root.title("BLAST the results of Velvet assembly")
    root.geometry('1200x900+100+100')
    filelist = []

    #all reads files
    tk.Label(root, text = "All reads passing filters (BEFORE Velvet): ").pack()
    lb_input_all_reads = tk.Listbox(root, height = 4, width = 150)
    lb_input_all_reads.pack()
    tk.Button( root,
                text="Delete",
                command = lambda: lb_input_all_reads.delete(END)
            ).pack()
    tk.Button( root,
                text='Add file',
                command = lambda: insert_a_filename_in_list(lb_input_all_reads, set_basedir = True)
            ).pack()
    tk.Label(root, text = "--------------------------------------").pack()

    #fastq file list
    tk.Label(root, text = "Contigs and singletons (AFTER Velvet - its output files): ").pack()
    lb_input_fastq = tk.Listbox(root, height = 4, width = 150)
    lb_input_fastq.pack()
    tk.Button( root,
                text="Delete",
                command = lambda: lb_input_fastq.delete(END)
                ).pack()
    tk.Button( root,
                text='Add file',
                    command = lambda: insert_a_filename_in_list(lb_input_fastq)
                   ).pack()
    tk.Label(root, text = "--------------------------------------").pack()


    #bin name
    tk.Label(root, text = "Bin name: ").pack()
    root.jmeno_binu = tk.StringVar()
    root.jmeno_binu.set('')
    tk.Entry(root, textvariable = root.jmeno_binu).pack()
    tk.Label(root, text = "--------------------------------------").pack()

    #what db for analysis
    tk.Label(root, text = "Database: ").pack()
    cmb_database = Combobox(root, value = sel_databases, state="readonly")
    cmb_database.pack()
    cmb_database.set(sel_databases[0])

    #how to analyze
    tk.Label(root, text = "Iterations: ").pack()
    cmb_iteration = Combobox(root, value = sel_iteration, state="readonly")
    cmb_iteration.pack()
    cmb_iteration.set(sel_iteration[0])

    #blast result depth
    tk.Label(root, text = "Max BLAST depth: ").pack()
    cmb_depth_blast = Combobox(root, value = sel_depth_blast, state="readonly")
    cmb_depth_blast.pack()
    cmb_depth_blast.set(sel_depth_blast[0])


    tk.Label(root, text = "--------------------------------------").pack()

    #actions
    btn_run_the_analysis = tk.Button(root, text='Run the analysis',
                   command = lambda: find_best_match( read_files = lb_input_all_reads.get(0,END),
                                                      velvet_output_files = lb_input_fastq.get(0,END),
                                                      bin_name = root.jmeno_binu.get(),
                                                      bin_dir = BASEDIR,
                                                      restriction = cmb_database.get(),
                                                      iteration = cmb_iteration.get(),
                                                      depth_blast = cmb_depth_blast.get()
                                                  )
                   ).pack()

    root.mainloop()

def ensure_we_have_files(files):
    '''waits until the files are all present, and all non-zero size'''

    missing_files = []
    print("Checking presence of files", files)
    missed = 0
    while True:
        missing_files = list([file for file in files if not(os.path.exists(file)
                                                            and os.path.isfile(file)
                                                            and os.path.getsize(file) > 1000)])
        if len(missing_files) > 0:
            missed = 1
            ts = time.time()
            print("%s --- Waiting for files %s"
                  % (datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S'), missing_files))
            time.sleep(300)
        else:
            break
    if missed > 0:
        time.sleep(30)    #allow the disk writing operations complete...
    return


def make_a_table_with_counts_of_remapped_reads(bin_numbers,
                            ngs_dirs,
                            study,
                            restriction):

     #### kde jsem sebral new refs?

     #### udělat všechny reference, co jen je na nich aspoň 1 hit. Nebo ne? Nebo vše??


    #2016 - new procedure

    #there is no table with mutual relation of the references
    if not new_refs.has_identity_table():
        new_refs.feed_in_private_references(fn_raw_fasta_refs)
        imported_refs = new_refs.get_todays_accessions()
        #this is long work - here a list of references is reduced by mutual similarity
        reduced_list_of_reference_accessions = new_refs.reduce_reference_list(
                            reflist = list(imported_refs),
                            max_length_difference = 250,
                            min_identity_level = 90
                    )
        #the original table is printed out
        new_refs.export_pairwise_identity_table(excel_fn = os.path.join(dir_new_refs,
                                                                        "_identity_table_before.xlsx"),
                                                accessions = list(imported_refs))
        #and a new one, documenting the reduction... this happens if the identity is high, and
        #there is no big difference in length
        new_refs.export_pairwise_identity_table(excel_fn = os.path.join(dir_new_refs,
                                                                        "_identity_table_after.xlsx"),
                                                accessions = reduced_list_of_reference_accessions)

        with open(fn_reduced_list_of_reference_accessions, mode="w") as handle_output:
            print("\n".join(reduced_list_of_reference_accessions), file = handle_output)
    else: #there is such a table, and we will rely on the presence of a list of references as well
        reduced_list_of_reference_accessions = sam_file_operations.get_reference_accessions(fn_reduced_list_of_reference_accessions)

    #at this point, we have a full identity table + a final list of used references

    ## (4) REMAP 1000, 10,000 or 100,000 randomly chosen original reads to each of the references, and note the number of hits.

    sam_file_operations.remap_reads(
        study = study,
        bins_for_remapping = bins_in_study,
        sample_size = sample_size,
        refs = new_refs,
        list_of_accessions = reduced_list_of_reference_accessions,
        outfile = ngs_dirs.mapping_outfile(min_length, min_coverage, bins_in_study, sample_size),
        suffix_sam_dir = "%d_%d" % (min_length, min_coverage),
        consume_reads = False
        )

    return






def malawi():
    print("#################################################")
    bin_dir = "/data/virology/ngs_virome/ngs_data/malawi/"#ngs_dirs.get_bin_dir(bin_number)
    bin_name = "skey1"#ngs_dirs.get_bin_name(bin_number)
    contig = "/data/virology/ngs_virome/ngs_data/malawi/" + bin_name
    velvet_output_files = (
        ngs_dirs.get_fn_velvet_contigs(bin_number),
        ngs_dirs.get_fn_velvet_unused_reads(bin_number)
    )
    files_with_reads = (
        ngs_dirs.get_fn_interlacer_pairs(bin_number),
        ngs_dirs.get_fn_interlacer_singles(bin_number)
    )

    print("Now we will search for best match to the contigs and reads")
    find_best_match(
        read_files = files_with_reads,
        velvet_output_files = velvet_output_files,
        bin_num = bin_number,
        ngs_dirs = ngs_dirs,
        restriction = "all_viruses",
        iteration = "automatic",
        depth_blast = 20,
        algorithm = "megablast"
    )

    print("The winner references will now serve as templates for remapping the reads")
    """(data_dir, rest) = os.path.split(bin_dir)
    sam_file_operations.process_bins(basedir = data_dir,
        bin_numbers = [bin_number],
        ngs_dirs = ngs_dirs,
        algorithm = algorithm,
        restriction = restriction
    )
    """


#---- MAIN PROCEDURE ----------------------------
def work_with_multiple_bins(bin_numbers,
                            ngs_dirs,
                            study,
                            restriction,
                            algorithm = "megablast",
                            depth_blast = 20,
                            wait_for_input_files = False,
                            ):
    '''Iterates the analytic process for multiple bins
    parameters:
    bin_numbers - a list of bin numbers to be processed
    wait_for_input_files - check whether the files are already there, useful when Linux virtual machine or other
                           computer is preparing the files just ahead of this process. Wait_for_input_files is
                           an option when Linux is doing its job while this script does not have all files ready.
    perform_sam_file_operations - whether the "winners" or "best identified matches" should serve immediately
                as templates for remapping the original reads
    algorithm - what blast should be done

    Output: in the respective directories
    '''

    print("Will work with bins %s" % bin_numbers)

    #oterate over the bins of interest
    for bin_number in bin_numbers:
        print()
        print("#################################################")
        print("Now working with bin %d" % bin_number)
        print("#################################################")
        bin_dir = ngs_dirs.get_bin_dir(bin_number)
        bin_name = ngs_dirs.get_bin_name(bin_number)

        velvet_output_files = (
                            ngs_dirs.get_fn_velvet_contigs(bin_number),
                            ngs_dirs.get_fn_velvet_unused_reads(bin_number)
                            )

        files_with_reads = (
            ngs_dirs.get_fn_interlacer_pairs(bin_number),
            ngs_dirs.get_fn_interlacer_singles(bin_number)
        )

        if wait_for_input_files:
            files_to_demand = []
            files_to_demand.extend(files_with_reads)
            files_to_demand.extend(velvet_output_files)
            print("checking presence of files")
            ensure_we_have_files(files_to_demand)

        print("Now we will search for best match to the contigs and reads")
        find_best_match(
                        read_files = files_with_reads,
                        velvet_output_files = velvet_output_files,
                        bin_num = bin_number,
                        ngs_dirs = ngs_dirs,
                        restriction = restriction,
                        iteration = "automatic",
                        depth_blast = depth_blast,
                        algorithm = algorithm
                        )
        
        print("\nAFTER find_best_match\n The winner references will now serve as templates for remapping the reads")
        (data_dir, rest) = os.path.split(bin_dir)
        sam_file_operations.process_bins(#basedir = data_dir,
                                         bin_numbers = [bin_number],
                                         ngs_dirs = ngs_dirs,
                                         algorithm = algorithm,
                                         restriction = restriction
                                         )


    return


#------------------------------------------------------------------------------
if __name__ == '__main__':
    #get_contigs_unmatched_to_viruses()

    #run_tblastx_for_malawi01_and_dipp01()

    # OPTION 1 - set it in the interactive mode
    #main_screen()


    #this is the currently processed study
    study = "norway12"
    study = "test_data"
    study = "malawi"
    #load all bins in the study
    ngs_dirs = NgsDirs(study = study)
    #pokus = NgsDirs(["/data/virology/ngs_virome/ngs_data"])
    #pokus.get_bins_from_directories(candidate_directories = (r"malawi/data", ))

    bin_numbers = sorted(ngs_dirs.bin_dirs.keys())

    bin_numbers = [15,16]#11,12,14,15,16]
    
    work_with_multiple_bins(bin_numbers,
                            ngs_dirs,
                            study,
                            wait_for_input_files = False,
                            restriction = "all_viruses",
                            depth_blast = 50,
			    algorithm = "megablast"
                            #algorithm = "tblastx",
                            )

    #here we will remap all reads / sample of reads to the obtained references, and make a table
    """
    make_a_table_with_counts_of_remapped_reads(
                            bin_numbers,
                            ngs_dirs,
                            study,
                            restriction = "all_viruses")
    """
