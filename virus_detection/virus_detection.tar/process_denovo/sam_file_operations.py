#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Handles remapping of reads using bwa, and certain operations with sam files
"""
#---IMPORTS-----------------------------------------------------------------------------
import os.path
import pickle
from os import listdir
from os.path import isfile, join
import io
import datetime
import time
import sys
import re
import tempfile

import shutil
import Bio
from Bio.Alphabet import IUPAC
from Bio.Seq import Seq
from Bio import SeqRecord, Alphabet, SeqIO

import random
import string

import xlsxwriter

#sys.path.append(r"E:\programs\nextgen\virome")
sys.path.append(r"/home/lljali/virome")#C:\programs\nextgen\virome")
from NgsDirs import NgsDirs
import references

#sys.path.append(r"E:\programs\modules")
from cigar import Cigar

#----- CLASSES -----
class SampleMatching():
    '''Class describing a single sample matching. Must be embedded into the MatchingMap'''
    def __init__(self, bin_num, fn_reads, fn_sam, fn_protocol = None ):
        self.bin_num = int(bin_num)
        self.fn_reads = fn_reads
        self.fn_sam = fn_sam
        self.fn_protocol = fn_protocol
        self.mapping_done = False
        self.mappings = {} #dict of mappings, may be either str or dict.
        self._total_reads = None
        self._read_names = None
        return

    def get_read_names(self):
        '''returns read names of all reads file'''
        if self._read_names is None:
            self._read_names = get_read_names_fa(self.fn_reads)
        return self._read_names

    def get_read_count(self):
        '''returns count of all reads of the bin'''
        if self._total_reads is None:
            self._total_reads = len(self.get_read_names())
        return self._total_reads


class MatchingMap():
    '''Matching_map: a class for storing and processing matches to reference sequences.

    Structure:
    a multi-level dict
        seqrecords_of_references = list of seq records of references
        bins: a dict characterizing the bins and the mapping results. Key is bin number
            fn_protocol = path to a protocol file
            fn_sam = path to the proposed sam file
            total_reads: total number of reads in the bin mapping
            read_names_list: the list of all read names in the bin (not compulsory, can be inferred from sam)
            mappings: key is accession number, value is the count of matched reads
                the "mappings" keeps only POSITIVE numbers; if no mapping, the reference
                is not mentioned. The count of zeroes can be inferred from the list
                of references one level up.

    The resulting map contains number of reads assigned to the reference. If a read belongs to more references,
    the scores are divided.


'''
    def __init__(self, seqrecords_of_references = [], pickle_name = ''):
        clean_seqrecords_of_references = []
        print(seqrecords_of_references)
        for x in seqrecords_of_references:
            if (type(x).__name__ == "SeqRecord"):
                clean_seqrecords_of_references.append(x)
            else:
                print (x, "blanks?") 
        self._seqrecords_of_references = clean_seqrecords_of_references
        
        if len(clean_seqrecords_of_references) > 0:
            #test whether the records are really seqrecords
            #if not all([type(x).__name__ == "SeqRecord" for x in clean_seqrecords_of_references]):
            #    print ("\n",type(x).__name__)
            #    raise ValueError("Not all in the queue are SeqRecords")
            
            #for record in self._seqrecords_of_references:
            self._reference_list = [record.id for record in self._seqrecords_of_references]
            self._bins = {}
            self._mapped = False
            self._match_table_consumed_done = False #whether a matching table was done with list of references
            self._mt_done = False #whether a plain matching table was done
            self._last_order_of_references = [] #last list of references
            self._last_set_of_bins = set() #set of bins for the last analysis of matching
            self._mt = {} #match table
        else:
            print("pickle name", pickle_name, len(clean_seqrecords_of_references))
            if not os.path.exists(pickle_name) or not os.path.isfile(pickle_name):
                raise ValueError("no reference seqrecords given, and no pickle name")
            self._bins = []
            self.load(pickle_name)
        return

    def save(self, file_name):
        '''saves the state of the matching map'''
        handle = open(file_name, mode = "wb")
        pickle.dump(self.__dict__, handle)
        handle.close()
        return

    def load(self, file_name):
        '''loads the state of the matching map'''
        if not len(self._seqrecords_of_references) == 0 or not len(self._bins) == 0:
            raise ValueError("the instance is not empty")
        handle = open(file_name, mode = "rb")
        self.__dict__.update(pickle.load(handle))
        handle.close()
        return

    def get_reference_list(self):
        '''returns the list of references to which the reads are mapped'''
        return self._reference_list

    def add_bin(self, bin_num, fn_reads, fn_sam, fn_protocol = None):
        '''adds a new bin'''
        self._bins[bin_num] = SampleMatching(bin_num, fn_reads, fn_sam, fn_protocol)
        self._mt_done = False
        self._mapped = False
        return

    def get_count_of_reads(self, bin_num):
        '''returns the total number of reads coming into the matching'''
        return self._bins[bin_num][total_reads]

    def match_by_bwa(self):
        '''performs a bwa session with the innards of the object'''
        if self._mapped:
            raise ValueError("already mapped")

        pairs_of_fasta_sam = {}
        for one_sm in self._bins.values():
            pairs_of_fasta_sam[one_sm.fn_reads] = one_sm.fn_sam

        bwa_session(
            query_fasta_sam_dict = pairs_of_fasta_sam,
            array_seqrecords     = self._seqrecords_of_references
            )

        self._mapped = True
        self._mt_done = False
        return

    def match_table_plain(self):
        '''Produces a otu-like table with all taxons and all samples in the MatchingMap instance.
        The intersections are reads per 100,000'''

        if self._mt_done:
            return self._mt
        else:
            #prepare a match table without consuming reads
            for bin_no, smatch in self._bins.items():
                print("match_table_plain processing bin%i" % bin_no)
                #print(bin_no)
                smatch.mappings = assess_sam_reads(smatch.fn_sam, remove_unmatched_from_sam = False)
                abs_counts = {k:0 for k in self._reference_list}
                ref_smp = self._mt.setdefault(bin_no, {k:0 for k  in self._reference_list})

                #first absolute counts for mapping
                for match_list in smatch.mappings.values():
                    num_matches = len(match_list)
                    if num_matches > 0:
                        for part in match_list:
                            abs_counts[part["ref_name"]] += (1 / num_matches)
                total_reads = smatch.get_read_count()
                count_matched_reads= sum(abs_counts.values() )
                abs_counts["_unmatched"] = total_reads - count_matched_reads
                #now relative to 100,000
                if total_reads == 0:
                    #raise ValueError("No reads in this bin")
                    print("No reads in this bin - why - Ondrej, test data " + str(bin_no))
                    break
                for k in self._reference_list: #recalculate to 100,000 reads
                    ref_smp[k] = int(100000*abs_counts[k] / total_reads)
                ref_smp["_unmatched"] = int(100000*abs_counts["_unmatched"] / total_reads)
        self._mt_done = True
        return self._mt

    def get_match(self, bin_no, ref_acc):
        '''returns one intersection of the table'''
        if not self._mt_done:
            raise ValueError("match table not done")
        return self._mt[bin_no][ref_acc]

    def print_match_table(self, xlsx_file = None, text_file = None):
        '''prints the plain match table into xlsx and/or tab delimited file'''
        if xlsx_file is None and text_file is None:
            raise AttributeError("no file name supplied")
        if not self._mt_done:
            self.match_table_plain()

        if xlsx_file is not None:
            #print xlsx table
            workbook = xlsxwriter.Workbook(xlsx_file)
            worksheet = workbook.add_worksheet()

            worksheet.write(0,0, "Acc")
            worksheet.write(0,1, "Descr")
            worksheet.write(0,2, "tax_l_0")
            worksheet.write(0,3, "tax_l_1")
            worksheet.write(0,4, "tax_l_2")
            worksheet.write(0,5, "tax_l_3||bin_no")
            for col, bin_no in enumerate(self._bins, 6):
                worksheet.write(0, col , "%02d" % bin_no)

            for row, record in enumerate(self._seqrecords_of_references, 1):
                worksheet.write(row,0, record.id)
                worksheet.write(row,1, record.description)
                annot = record.annotations
                taxonomy = annot.setdefault("taxonomy", [])
                while len(taxonomy) < 4:
                    taxonomy.append("-")
                worksheet.write(row,2, taxonomy[0])
                worksheet.write(row,3, taxonomy[1])
                worksheet.write(row,4, taxonomy[2])
                worksheet.write(row,5, taxonomy[3])

                for col, bin_no in enumerate(self._bins, 6):
                    worksheet.write(row, col , self.get_match(bin_no, record.id))

            row += 1
            worksheet.write(row,0, "unmatched_reads")
            for col, bin_no in enumerate(self._bins, 6):
                    worksheet.write(row, col , self.get_match(bin_no, "_unmatched"))
            workbook.close()

        if text_file is not None:
            #print xlsx table
            handle = open(text_file, mode = "w")
            first_line = ["Acc", "Descr", "tax_l_0", "tax_l_1", "tax_l_2",  "tax_l_3||bin_no"]
            for bin_no in self._bins:
                first_line.append("%02d" % bin_no)
            print("\t".join(first_line), file = handle)

            for record in self._seqrecords_of_references:
                one_line = [record.id, record.description]
                annot = record.annotations
                taxonomy = annot.setdefault("taxonomy", [])
                while len(taxonomy) < 4:
                    taxonomy.append("-")
                one_line.extend(taxonomy[0:4])

                for bin_no in self._bins:
                    one_line.append(str(self.get_match(bin_no, record.id)))
                print("\t".join(one_line), file = handle)
            one_line = ["unmatched", "unmatched", "unmatched", "unmatched", "unmatched", "unmatched"]
            for bin_no in self._bins:
                    one_line.append(str(self.get_match(bin_no, "_unmatched")))
            print("\t".join(one_line), file = handle)
        return

#############################################################################
#----- subroutines ---------
def get_reference_accessions(fn_accessions):
    '''From a simple text file, reads accessions (one per line) and returns a list
    Ignores any empty lines'''
    handle_accessions = open(fn_accessions)
    reference_accessions = [x.rstrip() for x in handle_accessions.readlines()
                            if not re.search(r"^\s*$", x, re.IGNORECASE)]
    handle_accessions.close()

    return reference_accessions


def get_read_names_fa(fname):
    '''Returns a list of sequence names in the order given in the source file'''

    fh = open(fname)
    parser = SeqIO.parse(fh, "fasta")

    names = []
    for record in parser:
        names.append(record.id)
    fh.close()

    return names

def assess_sam_reads(fn_sam,
                     remove_unmatched_from_sam = False,
                     delete_old_file = False,
                     min_map_quality = 0,
                     sort_order_of_accessions = None,
                     do_not_report_unmatched = True
                     ):
    '''Finds whether the reads are matched, and (if wanted) removes those unmatched.
    fn_sam = the filepath to the sam file to be assessed,
    remove_unmatched_from_sam (True) = whether a new file should be created, comprising of only
        the matched reads. Recreates the sam file without unmatched reads. The original file is
        kept with an .old extension unless it is scheduled for deletion.
    delete_old_file = (True) should the old file be deleted
    min_map_quality (0) = if we want to report also clipped or multiple matches, this has to be zero; only full matches,
       unique per genome, have a real quality listed by bwa.
    sort_order_of_accessions = (None) a list of accessions that is used for sorting all found matches
        within the ta
    do_not_report_unmatched = do not report items for unmatched reads.

    Returns: a dictionary keyed by read names
        values are lists of dictionaries of the matches.
        these have the structure of {"ref_name", "start_pos", "reversed", "cigar", "map_quality", "len_seq"}
        If unmapped, it is an empty list, but always a list.

    '''
    print(fn_sam)
    coord_dict = dict() #a dictionary with coordinate names. List of tuples inside.

    #open the reading handle for sam file, and possibly also writing handle.
    handle_sam_from = None
    handle_sam_to = None
    old_filename = None

    if remove_unmatched_from_sam:
        #first rename the old file
        old_filename = fn_sam + ".old"
        if os.path.exists(old_filename):
            os.remove(old_filename)
        os.rename(fn_sam, old_filename)

        #then open the old file
        handle_sam_from = open(old_filename)
        #open the target_file
        handle_sam_to = open(fn_sam, mode="w")
    else:
        handle_sam_from = open(fn_sam)

    #and read the sam file line by line

    for line in handle_sam_from:
        result_quick = re.search("^[^\t]+\t(\d+)\t", line)
        if result_quick:
            bitflag     = result_quick.group(1)
            #does the read have a "4" bit in the flag? The third bit shows "unmapped"
            #truncate the bits over 4
            num1 = int(bitflag) % 8
            #if it contains the bit 4.
            if num1 >= 4 and do_not_report_unmatched: #unmapped
                continue

        result1 = re.search("^@", line)
        if not result1:  #it is not a header - it may be a genuine read
            result2 = re.search("^([^\t]+)\t(\d+)\t([^\t]+)\t(\d+)\t(\d+)\t([^\t]+)\t([^\t]+)\t(\d+)\t(\d+)\t([^\t]+)", line)
            if result2: #has a name and a bit flag
                was_genuine_read = True
                read_name   = result2.group(1)
                bitflag     = result2.group(2)
                ref_name    = result2.group(3)
                pos         = int(result2.group(4))
                mapq        = int(result2.group(5))   #ZERO if multiple alignments, or negative decadic log of probability that the match is wrongs
                cigar       = result2.group(6)
                rnext       = result2.group(7)
                pnext       = int(result2.group(8))
                tlen        = int(result2.group(9))
                read_seq    = result2.group(10)

                num_reversed = int(bitflag) % 32 #as reversed is 16
                sense = 1
                if num_reversed >=16:
                    sense = -1

                #does the read have a "4" bit in the flag? The third bit shows "unmapped"
                #truncate the bits over 4
                num1 = int(bitflag) % 8
                #if it contains the bit 4.
                if num1 >= 4 or mapq < min_map_quality: #it is an unmapped read, or a poor match
                    if not do_not_report_unmatched:
                        ref_coord_dict_item = coord_dict.setdefault(read_name, [])
                        #appends nothing, just makes an empty structure if not present
                else: #the read is mapped
                    ref_coord_dict_item = coord_dict.setdefault(read_name, [])
                    ref_coord_dict_item.append({"ref_name": ref_name,
                                                "read_name": read_name,
                                                "start_pos": pos,
                                                "reversed" : sense,
                                                "cigar": cigar,
                                                "map_quality": mapq,
                                                "len_seq": len(read_seq)} )
                    if not handle_sam_to is None: handle_sam_to.write(line)
            else:
                raise ValueError("This sam line is weird %s" % line) #the read record is weird, not having a proper structure...
        else: #it is a header
            if not handle_sam_to is None: handle_sam_to.write(line)

    handle_sam_from.close()
    if not handle_sam_to is None: handle_sam_to.close()

    #now delete the old file
    if delete_old_file and not (old_filename is  None) and os.path.exists(old_filename):
        os.remove(old_filename)

    if sort_order_of_accessions is not None:
        def accession_sort_key(x):
            try:
                #takes parameter, tries to find its key "ref_name"
                #and looks it up in a list.
                position = sort_order_of_reference_accessions.index(x["ref_name"])
            except ValueError:
                #if not found, returns a very big value
                position = 999999
            return position

        #there exists an order for sorting the references
        for a_list in coord_dict.values():
            a_list.sort(key = accession_sort_key)

    return coord_dict



def add_coverage_from_sam_to_seqrecord( record, fn_sam ):
    '''Adds a track of coverage to the SeqRecord object

    Takes:
    record = SeqRecord that will be modified
    fn_sam = sam file with the mapping
    sliding_window = (10) the size of window that will be averaged

    Returns:
    nothing, the SeqRecord will be modified in place
    '''

    max_pos = len(record.seq)-1

    #first add a per letter annotation 'coverage'
    if not 'coverage' in record.letter_annotations:
        record.letter_annotations['coverage'] = [0 for x in range(len(record.seq))]

    #now get the coordinates dictionary
    coord_dict = assess_sam_reads(fn_sam,
                                  remove_unmatched_from_sam = False,
                                  delete_old_file = False)

    #now we have the coordinates in a dict: lets make the coverage.
    for readname, coords_list in coord_dict.items():
        for coords in coord_list: #WILL NOT WORK with complicated cigar scores!!!!
            start_pos = coords["start_pos"]
            cigar = coords["cigar"]
            cigar_obj = Cigar(cigar)
            stop_pos = start + cigar_obj.reference_length()
            for pos in range(start_pos, stop_pos): #from start to stop of the read
                try:
                    record.letter_annotations['coverage'][pos] += 1 #one more read coverage at this position
                except IndexError as e:
                    if not pos>max_pos:
                        print(pos, max_pos)
                        raise e
    return


def get_genes_with_coverage(seqrecord, covered_genes_fn = None,
                            tabular_output_fn = None, coverage_threshold = 6):
    '''Returns features of coding sequences. Writes the respective sequences into a single Fasta file
    The gene must be coverd in its entirety.

    Arguments:
    seqrecord = a SeqRecord object which contains all data, including the added coverage
    covered_genes_fn = a filename for the output fasta file
    tabular_output_fn = table with the results.
    coverage_threshold = a threshold for the minimum mean coverage for the gene to be reported.

    Returns: a table with resulting genes
    Writes a fasta file with sequences if a file name is provided.
    '''

    if not ('coverage' in seqrecord.letter_annotations):
        raise ArgumentError("The sequence record has no per-base coverage annotation")

    output_handle = None
    if not (covered_genes_fn is None):
        output_handle = open(covered_genes_fn, mode = "w")


    table = []
    table.append(['locus_tag', 'product', 'start', "end", "strand", "protein_id", "db_xref",
                  "coverage", "translation", "dna_sequence" ])

    for feature in seqrecord.features:
        if feature.type != "CDS":
            continue
        locus_tag = feature.qualifiers['locus_tag'][0]
        product =  feature.qualifiers['product'][0]
        start = min([feature.location.start, feature.location.end])
        end   = max([feature.location.start, feature.location.end])
        strand = feature.location.strand
        protein_id = feature.qualifiers.get('protein_id', ["NA"])[0]
        db_xref = feature.qualifiers.get('db_xref', ["NA"])[0]
        translation = feature.qualifiers.get('translation', ["NA"])[0]
        dna_sequence = feature.extract(seqrecord.seq)

        extracted_seqrecord = seqrecord[start: end]

        #apply the criteria of coverage
        coverage = extracted_seqrecord.letter_annotations['coverage'][:]

        print(locus_tag, product, start, end, strand, protein_id, db_xref, "%3.2f" % (sum(coverage)/len(coverage)), end = "" )

        if sum(coverage) < coverage_threshold * len(coverage):
            #the coverage is lower than we would like to have
            print(" ... avg cov low")
            continue
        if min(moving_avg(coverage)) < coverage_threshold:
            print(" ... local cov low")
            continue
        print(" ... OK!")

        extracted_seqrecord.id = "section_%d_%d_locus_%s_protein_%s_product_%s" %(
            start, end, locus_tag, protein_id, product
        )

        table.append( [locus_tag, product, start, end, strand, protein_id, db_xref,
                       "%3.2f" % (sum(coverage)/len(coverage)), translation, dna_sequence ] )
        if not (output_handle is None):
            SeqIO.write(extracted_seqrecord, output_handle, "fasta")

    if not (output_handle is None):
        output_handle.close()

    if not (tabular_output_fn is None):
        with open(tabular_output_fn, mode="w") as handle:
            for row in table:
                print("\t".join([str(item) for item in row]), file = handle)

    return table

def moving_avg(input_array, window = 3):
    output_array = []
    length = len(input_array)
    for x in range(0, length - window - 1 ):
        suma = sum(input_array[x:x+window])
        avg  = suma / window
        output_array.append(avg)
    return output_array


def get_matched_read_names_set(fn_sam):
    '''Returns a set with read names of reads that matched in the sam file.
    parameters: filename of the sam file
    '''

    matched_reads_set = set()

    #open the reading handle for sam file
    with open(fn_sam) as handle_sam_from:

        #and read the sam file line by line
        was_header = False

        for line in handle_sam_from:
            result1 = re.search("^@", line)
            if not result1:  #it is not a header - it may be a genuine read
                #does the read have a "4" bit in the flag? The third bit shows "unmapped"
                result2 = re.search("^([^\t]+)\t(\d+)\t", line)
                if result2: #has a name and a bit flag
                    read_name   = result2.group(1)
                    bitflag     = result2.group(2)
                    #truncate the bits over 4
                    num1        = int(bitflag) % 8
                    #if it contains the bit 4.
                    if num1 >= 4: #it is an unmapped read
                        pass #here we can add some operations...
                    else: #the read is mapped
                        matched_reads_set.add(read_name)
            else: #it is a header
                if was_header:
                    raise ValueError("Multiple headers in sam file %s" % fn_sam)
                was_header = True
    return matched_reads_set


def write_acc_description(handle, accs, refs):
    '''sends a line with acc and its name to the handle for each of accs'''
    for (i, acc) in enumerate(accs, 1):
        ref_seqrecord = refs.get(acc)
        print("%2d) acc %13s: %s" % (i, acc, ref_seqrecord.description )  , file=handle)


def random_file_name(prefix, length, suffix):
    '''creates a random file name'''
    file_name = prefix + "_" + ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(length)) + "."+ suffix
    return file_name



##########################################################################################################
#
# Handling bwa program to make a sam file
#
##########################################################################################################

def bwa_session(query_fasta_sam_dict,
                array_seqrecords = None,
                ref_fasta_fn = None,
                base_temp_directory = "/data/virology/ngs_virome/ngs_data/bwatemp/",
                bwa_exec_fn = "bwa",
                threads = 6
               ):

    '''Runs a set of bwa sessions where the reads are aligned to an array of reference sequences;
    Creates one sam file per one input file by mapping sequences to the references.
    - input must contain a fasta file with the short sequences to be mapped
    - and EITHER an array of seqrecords (even a single reference must be in an array)
      OR a fasta file (single or multiple reference sequences) that will serve for the mapping.

    Returns a dictionary with the file name of the queries as keys, and the resulting sam file as
    value. Nothing new, these are the input parameters, but what else to return...

    The complicated way of passing the parameters is for the sake of optimalization: the indexing
    of the references takes a substantial amount of time, and therefore should be optimally performed only once.
    Therefore it is wise to query as much as possible in a single sitting.

    Parameters:
        query_fasta_sam_dict: a dictionary with keys as paths to fasta files with the sequences to be mapped...
            and values as paths of sam files where the final sam file should be placed
        array_seqrecords = Bio.Seqrecord with the reference sequence OR an array with multiple seqrecords
        ref_fasta_fn = a file path/name, contains reference sequences (if no seqrecord is provided)
        base_temp_directory = base where temporary directories will be created for execution of the program
        bwa_exec_fn = filename of the bwa program
        base_temp_directory = base where temporary directories will be created for execution of the program
        threads = number of processor threads for this task

    Returns: nothing, the result is the set of sam files

    last revision: 2016-03-29 OC
    '''
    #----- check input parameters ------
    #if not os.path.exists(bwa_exec_fn):
    #    raise Exception("The BWA executable is not present at " + bwa_exec_fn)

    if sum([1 for fn_query in query_fasta_sam_dict.keys() if not os.path.isfile(fn_query)])  > 0 :
        #if any of the file names in the arrax of queries is not a valid file
        raise ValueError("The bwa search was given no valid file as the source of query sequences")

    #find a suitable single-use temporary directory.
    temp_directory = tempfile.mkdtemp(suffix='', prefix='tmp', dir=base_temp_directory)

    if ((ref_fasta_fn is None or not os.path.exists(ref_fasta_fn) or not os.path.isfile(ref_fasta_fn))
        and not (array_seqrecords is None)): #-- SOURCE: array of seqrecord.
        #put in the temp files
        fn_temp_ref = os.path.normpath(os.path.join(temp_directory, random_file_name("reference", 10, "fa")) )
        fh_ref      = open(fn_temp_ref, mode = "w")
        for ref_seqrecord in array_seqrecords:
            SeqIO.write(ref_seqrecord, fh_ref, format="fasta")
        fh_ref.close()
        filename_fasta_ref = fn_temp_ref
    elif ((os.path.exists(ref_fasta_fn) and os.path.isfile(ref_fasta_fn))
        and array_seqrecords is None): #-- SOURCE: fasta:
        filename_fasta_ref = ref_fasta_fn
    else:
        raise ValueError("The bwa search was given no valid references to map to - neither seqrecord, nor fasta")


    #----- prepare the command -----
    bwa_commands = []
    #this is the trick, we will index only ONCE...
    bwa_commands.append(
        "%s index %s " % (bwa_exec_fn,
                          filename_fasta_ref)
    )
    #and now we will run mapping for all the query files
    for fn_query, output_sam_filename in query_fasta_sam_dict.items():
        bwa_commands.append(
            "%s bwasw -t %d %s %s > %s" %(bwa_exec_fn,
                                    threads,
                                    filename_fasta_ref,
                                    fn_query,
                                    output_sam_filename)
        )

    #now run it!
    perform_system_commands(bwa_commands, temp_directory)

    #----- clean up
    #TODO: problems with accessing this directory...
    if os.path.exists(temp_directory):
        shutil.rmtree(temp_directory, ignore_errors=True)
    return

def bacterial_ribosomal_bwa_session(fn_query, output_sam , threads = 6):
    '''performs bwa mapping on bacterial ribosomal sequences, collected from various databases, and reduced by similarity
    Wraps the indexed bwa session function'''
    return indexed_bwa_session(fn_query,
                               output_sam,
                               threads = threads,
                               indexed_genome_directory = r"E:\ngs_data\reference_sequences\all_bacterial_ribosomes",
                               indexed_genome_fasta = "reduced_bacterial_ribosomal.fa",
                               bwa_exec_fn = r"bwa")


def human_bwa_session(fn_query, output_sam, threads = 6):
    '''performs bwa mapping on human indexed genome from 1000 genomes. hg 37
    Wraps the indexed bwa session function'''
    return indexed_bwa_session(fn_query,
                               output_sam,
                               threads = threads,
                               indexed_genome_directory = r"E:\ngs_data\reference_sequences\human",
                               indexed_genome_fasta = "human_g1k_v37.fasta",
                               bwa_exec_fn = r"bwa")


def indexed_bwa_session(fn_query,
                        output_sam,
                        indexed_genome_directory,
                        indexed_genome_fasta,
                        bwa_exec_fn = r"bwa",
                        threads = 6
                    ):

    '''runs a bwa session where the reads are aligned to the already indexed genomic sequence or set of sequences;
    Creates a sam file by mapping sequences for the genome, and transcriptome
    - input must contain a fasta file with the short sequences to be mapped
    - and EITHER a seqrecord (single reference) OR a fasta file (single or multiple
    reference sequences) that will serve for the mapping.

    Returns the normalized file name of the sam file (what else...).

    Parameters:
        fn_query = a fasta file with the sequences to be mapped...
        output_sam = file where the final sam file should be placed for genome mapping
        indexed_genome_directory = where the INDEXED genome sits (previously indexed with bwa index -a bwtsw reference.fa)
        indexed_genome_fasta = the name of the fasta file, without the path.
            This separation is needed because the command runs in the directory.
        bwa_exec_fn = filename of the bwa program
        threads = number of processor threads for this task
    '''


    #----- check input parameters ------
    if not os.path.exists(bwa_exec_fn):
        raise Exception("The BWA executable is not present at " + bwa_exec_fn)
    if (not os.path.isdir(indexed_genome_directory)
       or not os.path.isfile(os.path.join(indexed_genome_directory, indexed_genome_fasta)) ):
        raise ValueError("There is no directory with indexed genome")



    #----- prepare the command -----
    bwa_commands = []
    bwa_commands.append(
        "%s bwasw -t %d %s %s > %s" %(bwa_exec_fn,
                                threads,
                                os.path.join(indexed_genome_directory, indexed_genome_fasta),
                                fn_query,
                                output_sam)
    )
    #---- go into the dir with indexed human reference
    perform_system_commands(bwa_commands, indexed_genome_directory)
    #---- return the sam file name (with path)
    return output_sam


#perform system commands
def perform_system_commands(system_commands, work_directory):
    original_dir = os.getcwd()
    os.chdir(work_directory)
    for command in system_commands:
        try:
            #perform the command as if it were sent to the "command window"
            print(command)
            os.system(command)
        except Exception as e: #if there is an exception, print it and re-raise
            print(e)
            raise
        finally:
            os.chdir(original_dir)
    return

#------currently unused function------------------------------------------------------
def remove_reads_from_file(fn_fasta, list_to_remove):
    '''Removes the sequence entries from the given fasta file'''

    if len(list_to_remove) == 0: #return if nothing has to be removed. (File unchanged)
        return

    #rename the source file and the destination file, and open both.
    #first rename the old file
    old_filename = fn_fasta + ".old"
    if os.path.exists(old_filename):
        os.remove(old_filename)
    os.rename(fn_fasta, old_filename)

    #then open the old file
    handle_fasta_from = open(old_filename)
    #open the target_file
    handle_fasta_to = open(fn_fasta, mode="w")

    #iterate through records, and retain only those not on the list
    for record in SeqIO.parse(handle_fasta_from, "fasta"):
        if not record.id in list_to_remove:
            SeqIO.write(record, handle=handle_fasta_to, format="fasta")

    #close both handles
    handle_fasta_from.close()
    handle_fasta_to.close()

    #and remove the old file
    os.remove(old_filename)

    return


#----------------------------------------------------------------------------------------------------------
#
# this is called by main.
#
#----------------------------------------------------------------------------------------------------------
def map_reads_to_references(bins_queries_outputdirs,
                            reference_accessions,
                            refs,
                            sam_file_prefix = "", study = "",
                            type_reflist = "reduced", consume_reads = True,
                            max_count = 100000,
                            retain_auxiliary_files = True
                            ):

    '''Runs bwa for each of references, using the original unrestricted set of all reads
    or gradually consumed set of reads.

    Parameters:
    bins_queries_outputdirs = list of dicts: for each bin number a three item list is given,
        consisting of bin_number ('bin_num'), query identification ('fn_query'), and sam file directory ('dir_for_sam_files')

    bin_name = name of the processed bin
    outputdir = output directory for the sam files
    fn_reads = file where the reads for mapping are, prior to any assembly, just filtered
    reference_accessions = list of references (accessions) to be provided for the analysis
    refs = object 'references' that actually contains the ref sequences
    sam_file_prefix = how should the sam file names be preceded?
    type_reflist = "reduced" when reduction is done prior to the mapping, based on mutual relatedness of the references
                 = "original" when all reference sequences are taken, even if overlapping with the others
    consume_reads = True if reads once aligned are NOT reused in subsequent rounds of mapping
                  = False if mapping starts always with the full set of reads, even if the reference is deep in the list
    max_count = maximum number of assemblies that will be done
    retain_auxiliary_files = will the genbank or fasta reference, and the sam file, be retained?
    Returns:
    matching_map: an instance of the class MatchingMap

    '''
    #--------------------------------------------------------------------------
    #LIST OF REFERENCES - these are common to all the mapped samples.
    #how to define common references for mapped samples, defined at project level, system? learned
    reflist = None
    #type_of_reflist:
    if type_reflist == "reduced":
        reflist = refs.reduce_reference_list( reference_accessions )
    elif type_reflist == "original":
        #all references, even the repetitive
        #get all accession numbers ordered by relevance in this tabmatch table
        reflist = list(reference_accessions)
    total_refs = len(reflist)
    seqrecords_of_references = []
    #prepare the records of references.
    for acc in reflist[:max_count+1]:
        ref_seqrecord = refs.get(acc)
        seqrecords_of_references.append(ref_seqrecord)
    #---------------------------------------------------------------------------
    #the object of MatchingMap stores the results of the matching session
    matching_map = MatchingMap(seqrecords_of_references = seqrecords_of_references)
    #now the individual samples - bins, and their data
    for trio_ref in bins_queries_outputdirs:
        #iterates over the bins that have to be mapped.
        bin_num   = trio_ref['bin_num']
        fn_reads  = trio_ref['fn_query']
        outputdir = trio_ref['dir_for_sam_files']
        fn_protocol = os.path.join(outputdir, "bin%02d_protocol_of_mapping.txt" % bin_num)
        #name of sam file
        sam_path = os.path.join(outputdir, '%sbin%02d.sam' %( sam_file_prefix, bin_num))
        matching_map.add_bin(bin_num = bin_num,
                             fn_reads = fn_reads,
                             fn_sam = sam_path,
                             fn_protocol = fn_protocol)

    #perform the matching and obtain sam files.
    print(">>> RUNS BWA")
    matching_map.match_by_bwa()
    print("<<< BWA complete")

    print(">>> assessment of the match table")
    pokout = "pokus1" + study
    tpf = "/home/lljali/virome/process_velvet_results/test_data_match/" + study + ".tsv"
    matching_map.print_match_table(text_file = tpf) #r"/home/lljali/virome/process_velvet_results/test_data_match/pokus1.tsv")#xlsx")
    print("<<< assessment of the match table DONE")

        #
        #
        # print("\n\nNow we will iterate through %d reads and %d references" % (len(read_names_list), total_refs))
        #
        # handle_protocol =  open(fn_protocol, mode="w")
        # print("PROTOCOL OF MAPPING: %s" %bin_name , file=handle_protocol)
        # print("\nFiles are in %s" % outputdir, file=handle_protocol)
        # print("File with reads: %s" % fn_reads, file=handle_protocol)
        # print("\nOriginal reference accessions %d:" % len(reference_accessions), file=handle_protocol)
        # write_acc_description(handle_protocol, reference_accessions, refs)
        #
        # if type_reflist == "reduced":
        #     print("\nThe list of references has been reduced by their mutual relatedness to %d:" % len(reflist), file=handle_protocol)
        #     write_acc_description(handle_protocol, reflist, refs)
        # else:
        #     print("and this list was used for mapping", file=handle_protocol)
        # print("\n\n___________________________________________", file=handle_protocol)
        # print("Mapping started on %s at %s" % (datetime.datetime.now().date(), datetime.datetime.now().time()), file=handle_protocol)
        #
        #
         # #for consuming reads
        # remaining_reads = []
        # if not os.path.exists(outputdir):
        #     os.makedirs(outputdir)
        # fn_remaining_reads = os.path.join(outputdir, "remaining_reads.fa")
        #

        #
        # #now for each accession, make a bwa alignment
        # for (order_no, acc) in enumerate(reflist[:max_count+1], 1):
        #     print("\nStarting work with reference %d of %d" %(order_no, total_refs))
        #     handle_protocol.flush()
        #     #files for deletion if retain_auxiliary_files = False
        #
        #     #---- REFERENCE FILES ----
        #     #first write the reference to a fasta file, and a genbank file. It will be needed for the Tablet.
        #     # fn_ref_fa = '%s/%s_seq_%03d_%s_ref.fa' %(outputdir, bin_name, order_no, acc)
        #     # fn_ref_gb = '%s/%s_seq_%03d_%s_ref.gb' %(outputdir, bin_name, order_no, acc)
        #     # ref_seqrecord = refs.get(acc)
        #     # SeqIO.write(ref_seqrecord, fn_ref_fa, "fasta")
        #     # SeqIO.write(ref_seqrecord, fn_ref_gb, "genbank")
        #     # auxiliary_fns_for_deletion.add(fn_ref_fa)
        #     # auxiliary_fns_for_deletion.add(fn_ref_gb)
        #
        #     #---- BWA alignment ----
        #
        #
        #     #selecting the source: first iteration all, then either all or diminishing list of all reads
        #     fn_query = None
        #     if consume_reads and order_no > 1:
        #         fn_query = fn_remaining_reads
        #         auxiliary_fns_for_deletion.add(fn_remaining_reads)
        #     else:
        #         fn_query = fn_reads
        #
        #
        #
        #     #---- ASSESSMENT OF THE RESULT -------
        #     if consume_reads: #reads are NOT reused; if aligned, they are "consumed"
        #         #assess the sam reads file, and remove the unmatched reads from sam
        #         sam_names_dict = assess_sam_reads(sam_filename,
        #                                           remove_unmatched_from_sam = True,
        #                                           delete_old_file = True)
        #
        #         #---- consuming matched reads ----
        #         #now finalize the results - remove the matched reads from the common pool if the reads are "consumed"
        #         total_reads = len(sam_names_dict.keys())
        #         mapped_read_names = [k for (k,v) in sam_names_dict.items() if v > 0]
        #         mapped_read_set = set(mapped_read_names)
        #         n_mapped_reads = len(mapped_read_names)
        #
        #         if order_no == 1: #first iteration. Read all sequences and prepare for reductions
        #             print("Will parse all reads on %s at %s" % (datetime.datetime.now().date(), datetime.datetime.now().time() ))
        #             remaining_reads = list(SeqIO.parse(fn_all_reads, "fasta"))
        #             print("Parsed all reads on %s at %s" % (datetime.datetime.now().date(), datetime.datetime.now().time() ))
        #
        #         n_tot = len(remaining_reads)
        #         #reduce by the matched ones (list comprehension) TODO: IMPROVE PERFORMANCE!
        #         new_remaining_reads = []
        #
        #         print("started deletions in %d remaining reads on %s at %s"
        #               % (n_tot, datetime.datetime.now().date(), datetime.datetime.now().time() ))
        #
        #         #we had a problem with speed of the used algorithm
        #         #the mapped reads are more frequent, we will not REMOVE them, we will copy the others
        #         for (i, read) in enumerate(remaining_reads):
        #             if i % 50000 == 0:
        #                 print("         %d reads of %d done at %s" % ( i , n_tot, datetime.datetime.now().time()))
        #             if not read.id in mapped_read_set: #if it is NOT among the mapped reads
        #                 new_remaining_reads.append(read) #it writes the read into remaining reads
        #             else: #but if it is among the mapped reads, then it is removed and there is no need to test it next time
        #                 mapped_read_set.remove(read.id)
        #
        #         handle_output = open(fn_remaining_reads, mode = "w")
        #         SeqIO.write(new_remaining_reads, handle_output, "fasta")
        #         handle_output.close()
        #
        #         print("While the original remaining_reads had %d record\nthe new version has %d records, \ni.e. %d less."
        #               %(n_tot, len(new_remaining_reads), len(new_remaining_reads) - n_tot))
        #
        #         remaining_reads = new_remaining_reads
        #         print("Done deletions on %s at %s" % (datetime.datetime.now().date(), datetime.datetime.now().time() ))
        #
        #     else: #reads not consumed
        #         sam_names_dict = assess_sam_reads(sam_filename,
        #                                           remove_unmatched_from_sam = False,
        #                                           delete_old_file = False)
        #
        #         total_reads = len(sam_names_dict.keys())
        #         n_mapped_reads = sum(sam_names_dict.values())
        #
        #     #store the number of mapped reads per 100,000
        #     count_of_reads_matched_to_acc[acc] = int(100000*n_mapped_reads/total_reads)
        #     #---- print into the record ----
        #     print("%4d) of %10d reads, %8d mapped to acc %13s: %s"
        #           % (order_no, total_reads, n_mapped_reads,  acc, ref_seqrecord.description )  ,
        #           file=handle_protocol)
        #     print("Done with reference %d of %d" %(order_no, total_refs))
        #
        # #deleting all auxiliary files.
        # if not retain_auxiliary_files:
        #     for fn_to_delete in auxiliary_fns_for_deletion:
        #         os.remove(fn_to_delete)
        #
        # print("\nMapping finished on %s at %s" % (datetime.datetime.now().date(), datetime.datetime.now().time()), file=handle_protocol)
        #



    return matching_map

#############################################################################################x
#
#  for unknown sequences. Called from "associate unknown sequences"
#
##############################################################################################x


def remap_reads(ngs_dirs, bins_for_remapping, sample_size, fn_outfile,
                refs = None, list_of_accessions = [],
                suffix_sam_dir = "unknown",
                retain_auxiliary_files = False,
                consume_reads = False):

    '''Remaps a sample of the original reads to the selected reference files.

    Parameters: ngs_dirs = object of class NgsDirs
                bins_for_remapping = list of bin nums
                sample_size = number of reads to remap: 1000, 10000 or 100000
                refs  = object 'references' containing the reference sequences
                list_of_accessions = accessions (or provisional ones) for the matching - need not be all from refs
                dict_of_reference_fasta_files = dict of file paths to additional mapping files,
                    key is the name for the sequence, value is the file path
                fn_outfile     = path to the output file
                suffix_sam_dir = a suffix distinguishing this mapping run from others.
                                Will appear in the sam directory; e.g. 2000_100 for unknown contigs 2000+ long with cov 100+
                                or all_viruses for remapping results of blast of all viruses.
                retain_auxiliary_files = will the sam file and references  be deleted after the
                    count of matches is found? Default False, i.e. will be deleted.
                consume_reads = False, every reference is mapped against the original reads set; True, once mapped read is removed from the read set
    The result is a text file (fn_outfile)

    Returns a complex two-level hash with first key the sample, the second the accession,
    and number of mapped reads / 100,000 in the intersection.'''


    #---- prepare data structures ----
    #for results
    result_table = {} #a complex hash - first level is keyed by samples, the second by ref accessions
    #print into the result table
    list_of_organism_names = sorted(dict_of_reference_fasta_files.keys())
    handle_outfile = open(fn_outfile, mode="w")
    print("BIN/ACC\t" + "\t".join(list_of_accessions) + "\t".join(list_of_organism_names), file = handle_outfile)
    handle_outfile.close() #closes because the mapping can break any time


    trios_bin_query_samdir = []
    for bin_num in bins_for_remapping:
        #find the file with the read sample
        fn_reads = ngs_dirs.get_fn_sample_of_reads(bin_num = bin_num,
                                                   sample_size = sample_size)
        dir_for_sam_files = ngs_dirs.get_sam_dir_remapping(bin_num, suffix_sam_dir, "remapping")
        trios_bin_query_samdir.append({'bin_num':bin_num,
                                       'fn_query':fn_reads,
                                       'dir_for_sam_files':dir_for_sam_files}
            )

        result_table[bin_num] = {}

    #--- do we have a references object which contains gen bank files
    if (refs is not None and
        isinstance(refs,  references.References)
        and len(list_of_accessions)>0):
        scores = map_reads_to_references(
                                        trios_bin_query_samdir,
                                        reference_accessions = list_of_accessions,
                                        refs = refs, #the object provided above
                                        type_reflist = "original",
                                        consume_reads = consume_reads,
                                        max_count = 99999999,
                                        retain_auxiliary_files = retain_auxiliary_files
                                    )
        #TODO !!!!!!!
        result_table[bin_num].update(scores) #adds the hash to the existing one.


        #write ONE LINE into the result table. Then close it.
        handle_outfile = open(fn_outfile, mode="a")
        print("%02d\t" % bin_num
              + "\t".join([str(scores[x]) for x in list_of_accessions])
              + "\t".join([str(scores[x]) for x in list_of_organism_names]),
              file = handle_outfile)
        handle_outfile.close()
        #closes until the next line, the mapping can break any time.

    return result_table

#########################################################################################
#
#--------------------- main procedure --------------------
#
#########################################################################################
def process_bins(bin_numbers,
                 ngs_dirs,
                 algorithm,
                 restriction
                 ):

    '''Maps reads to the selected reference files; processes sequentially a set of bins
    Main procedure of the remapping module

    bin_numbers = list of bin numbers to be processed
    ngs_dirs = object of class NgsDirs, contains info on the file locations
    algorithm, restriction = refer to how the reference files were identified ...
            e.g. megablast, all viruses.

    returns nothing.
    '''
    print("Mapping started on %s at %s" % (datetime.datetime.now().date(), datetime.datetime.now().time()))
    default_refs = references.References()

    trios_bin_query_samdir = []

    for bin_num in bin_numbers:
        bin_name = ngs_dirs.get_bin_name(bin_num)
        bin_dir  = ngs_dirs.get_bin_dir(bin_num)
        sam_dir  = ngs_dirs.get_sam_dir(bin_num, algorithm, restriction)

        fn_all_reads = ngs_dirs.get_fn_all_reads(bin_num)

        #from a file with listed accessions, gets a simple list
        fn_winners = ngs_dirs.get_fn_winner_accessions(bin_num, algorithm, restriction)
        print("fn_winners is it blank?", fn_winners, algorithm, restriction)
        reference_accessions = get_reference_accessions(fn_winners)
        print("reference_accessions", reference_accessions)
        #append is empty, and is trios_bin_query_samdir used after this?
        #trios_bin_query_samdir.append()
        dir_for_sam_files = sam_dir #seems strange that I need to comment out trios...append() and define sam_dir, seems like process_velvet_results are not being used maybe (Ondrej)
        map_reads_to_references(
            [{'bin_num': bin_num, 'fn_query': fn_all_reads, 'dir_for_sam_files': dir_for_sam_files}],
            reference_accessions, default_refs,
            type_reflist = "reduced", consume_reads = True, max_count = 30  )


#
def process_bins_for_adenovirus(basedir, bin_names):
    for bin_name in bin_names:
        sam_dir = os.path.join(basedir, bin_name, "sam")
        fn_all_reads = os.path.join(sam_dir, "all_reads.fa")

        reference_accessions = ['AC_000017.1', 'AC_000019.1', 'NC_011202.1', 'AC_000007.1']
        map_reads_to_references(bin_name, outputdir = os.path.join(basedir, "adenovirus") ,
                                fn_all_reads = fn_all_reads, reference_accessions = reference_accessions, refs = default_refs,
                                type_reflist = "reduced", consume_reads = True,
                                max_count = 50)


def test_remapping_human_reads():
    '''a function that tests the filter of human and bacterial sequences'''


    input_fn = r"E:\programs\nextgen\virome\process_velvet_results\test_data\test_contigs.fa"
    input_fn = "/data/virology/ngs_virome/ngs_data/test_data/data/bin83/velvet/contigs.fa"
    human_sam_fn = r"E:\programs\nextgen\virome\process_velvet_results\test_data\human_of_contigs.sam"
    human_bwa_session(input_fn, human_sam_fn)
    coord_dict1 = assess_sam_reads( human_sam_fn,
                                    remove_unmatched_from_sam = True,
                                    delete_old_file = True )
    print("Human ", coord_dict1)


    bact_rib_sam_fn = r"E:\programs\nextgen\virome\process_velvet_results\test_data\bact_rib_of_contigs.sam"
    #bacterial_ribosomal_bwa_session(input_fn, bact_rib_sam_fn )
    #coord_dict2 = assess_sam_reads(bact_rib_sam_fn,
    #                                        remove_unmatched_from_sam = True,
    #                                        delete_old_file = True)
    #print("Bacterial ribosomes ", coord_dict2)

    return



def test_remapping_multiple_contig_files_to_multiple_references(study):
    '''a function that tests simultaneous mapping to several things at the same time'''
    #this is the currently processed study
    #study = "test2" #norway12
    #load all bins in the study
    ngs_dirs = NgsDirs(study = study)
    refs = references.References()
    all_ref_acc = []
    saved_map_filepath = "/data/virology/ngs_virome/ngs_data/" + study + "/map.map"
    if (True):#os.path.exists(saved_map_filepath) and os.path.isfile(saved_map_filepath):
        #test_map = MatchingMap(pickle_name = saved_map_filepath)
        #else:
        test_bqr = []
        bins = ngs_dirs.get_bin_nums()
        for bin_num in ngs_dirs.get_bin_nums():
            #sequences
            trio = {
                'bin_num': bin_num,
                'fn_query': ngs_dirs.get_fn_all_reads(bin_num),
                'dir_for_sam_files': ngs_dirs.get_sam_dir(bin_num, "megablast", "all_viruses")
            }
            test_bqr.append(trio)
            #and the references
            fn_winners = ngs_dirs.get_fn_winner_accessions(bin_num, "megablast", "all_viruses")
            #print(fn_winners)
            for one_acc in get_reference_accessions(fn_winners):
                if one_acc not in all_ref_acc:
                       all_ref_acc.append(one_acc)
        #test_map = map_reads_to_references(test_bqr, all_ref_acc, refs,
        #                                   sam_file_prefix = "test_del_later_")
        test_map = map_reads_to_references(test_bqr, all_ref_acc, refs,
                                           sam_file_prefix = "test_del_later_", study = study)
        test_map.save("/data/virology/ngs_virome/ngs_data/" + study + "/map.map")
    #now we have the map...
    return

def test_malawi(study):
    '''a function that tests simultaneous mapping to several things at the same time'''
    #this is the currently processed study
    #study = "test2" #norway12
    ngs_dirs = NgsDirs(study = study)
    refs = references.References()
    all_ref_acc = []
    saved_map_filepath = "/data/virology/ngs_virome/ngs_data/" + study + "/map.map"
    if (True):#os.path.exists(saved_map_filepath) and os.path.isfile(saved_map_filepath):
        #test_map = MatchingMap(pickle_name = saved_map_filepath)
        #else:
        test_bqr = [] #get_fn_all_reads must use /study/interlaced/XX
        #this needs bin numbers too?
        for bin_num in ngs_dirs.get_bin_nums():
            #sequences
            trio = {
                'bin_num': bin_num,
                'fn_query': ngs_dirs.get_fn_all_reads(bin_num),
                'dir_for_sam_files': ngs_dirs.get_sam_dir(bin_num, "megablast", "all_viruses")
            }
            print (trio)
            test_bqr.append(trio)
            #and the references
            fn_winners = ngs_dirs.get_fn_winner_accessions(bin_num, "megablast", "all_viruses")
            print(fn_winners)
            for one_acc in get_reference_accessions(fn_winners):
                if one_acc not in all_ref_acc:
                       all_ref_acc.append(one_acc)
        #test_map = map_reads_to_references(test_bqr, all_ref_acc, refs,
        #                                   sam_file_prefix = "test_del_later_")
        print("before map_reads")
        test_map = map_reads_to_references(test_bqr, all_ref_acc, refs,
                                           sam_file_prefix = "test_del_later_", study = study)
        test_map.save("/data/virology/ngs_virome/ngs_data/" + study + "/map.map")
    #now we have the map...
    return


if __name__ == '__main__':
    #test_remapping_human_reads()
    import sys
    study = "malawi"
    if (len(sys.argv) >= 2):
        study = sys.argv[1]
    test_remapping_multiple_contig_files_to_multiple_references(study)
    #test_malawi(study)
    pass
    #print(get_reference_accessions("E:/ngs_data/ngs_virome/test_data/data/bin83/sam/accessions_of_winner_references.txt"))
