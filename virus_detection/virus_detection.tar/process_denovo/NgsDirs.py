#!/usr/bin/env python3
# -*- coding: utf-8 -*-


'''
Manages the directories in a NGS virome run.
Enables to handle files and directories without directly naming them.

'''


import re

import os.path
import os
from Bio import SeqIO
import random
import gzip
# from os import listdir
# from os.path import isfile, join
# import io
# import time
# import datetime
# import sys
# import pickle
import shutil




#a function outside class - called from within
def _make_a_sample_of_fasta(all_reads_filename, sample_filename, sample_size):
    '''Makes a random sample of fasta reads from all_reads_filename
    into a new file, with a size of "sample_size" '''

    all_reads_handle = open(all_reads_filename)
    all_reads_parser = SeqIO.parse(all_reads_handle, "fasta")
    all_reads = list(all_reads_parser)
    all_reads_handle.close()

    chosen_reads = []
    if len(all_reads) <= sample_size:
        chosen_reads = all_reads.copy()
    else:
        chosen_reads = random.sample(all_reads, sample_size)

    sample_handle = open(sample_filename, mode = "w")
    SeqIO.write(chosen_reads, sample_handle, "fasta")
    sample_handle.close()

    return

def unzip(gz_from, unzip_to, move = True):
    handle_from = gzip.open(gz_from, 'rb')
    handle_to = open(unzip_to, 'wb')
    handle_to.write( handle_from.read() )
    handle_from.close()
    handle_to.close()
    
    if move:
        os.remove(gz_from)

class NgsDirs:
    '''Find the place where the data are; provide the file names for common tasks
    and operations with the NGS data
    '''

    def __init__(self,
                 study,
                 ngs_virome_dirs = ["/data/virology/ngs_virome/ngs_data"],#/data/E:/ngs_data/ngs_virome", "C:/ngs_data/ngs_virome"],
                 run_directories = []
                ):
        '''Initialization parameter:
            study (obligatory) = name of the study, it serves for finding the directories
            ngs_virome_dirs = list of dirs where the virome may sit; takes the first that exists.
            run_directories = list of working directories, complete path - if listed, the program will not look up
               the implicit run directories for the study
        Initialization also looks up the bins within the directories.
        '''

        #bins where the data sit; keyed by bin numbers
        self.bin_dirs = {}
        self._bins_listed = False
        self._study = study.lower()

        for ngs_virome_dir in ngs_virome_dirs:
            if os.path.exists(ngs_virome_dir) and os.path.isdir(ngs_virome_dir):
                self.ngs_virome_dir = ngs_virome_dir
                print("The virome dir is " + self.ngs_virome_dir)
                break

        else:   # executed after "for" terminates normally, i.e. not by break
            raise ValueError("No directory with NGS data")

        if len(run_directories) == 0:
            self.VIROME_RUN_DIRS = {
                "dipp01": [
                    os.path.join(self.ngs_virome_dir, "virome_07_dipp73-96"),
                    os.path.join(self.ngs_virome_dir, "virome_08_dipp49-72"),
                    os.path.join(self.ngs_virome_dir, "virome_09_dipp01-24"),
                    os.path.join(self.ngs_virome_dir, "virome_10_dipp25-48"),
                ] ,
                "malawi": [
                    os.path.join(self.ngs_virome_dir, "malawi"),
                ],
                "malawi02": [
                    os.path.join(self.ngs_virome_dir, "virome_11_malawi"),
                ],
                "calici02": [
                    os.path.join(self.ngs_virome_dir, "virome_11_calici"),
                ],
                "test": [
                    os.path.join(self.ngs_virome_dir, "test_data"),
                ],
                "norway12": [
                    os.path.join(self.ngs_virome_dir, "virome_12_norway"),
                ]
            }

            self._run_directories = self.VIROME_RUN_DIRS[self._study]
        else:
            self._run_directories = run_directories

        self._get_bins_from_directories()

        return

    def _get_bins_from_directories(self, sample_prefix="bin"):
        '''Attempts to find binxx in candidate directories that have a given prefix and \d+ pattern
        Lists these bin directories into the dictionary with samples'''

        candidate_directories = self._run_directories

        for candidate_directory in candidate_directories:
            full_path = os.path.normpath( os.path.join(self.ngs_virome_dir, candidate_directory, "data") )
            if not(os.path.exists(full_path) and os.path.isdir(full_path)):
                raise ValueError("This candidate directory for searching bins does not exist: %s" % full_path)
            child_directories = os.listdir(full_path)

            for one_child in child_directories:
                pattern = sample_prefix + r"(\d+)$"
                result = re.search(pattern, one_child, re.I)
                full_path_child = os.path.normpath( os.path.join(full_path, one_child) )
                if result and os.path.isdir(full_path_child): #we have it - it is a dir, and has the extension structure
                    #add it into the dict
                    self.bin_dirs[int(result.group(1))] = full_path_child

        print("Detected %d bin directories" % len(self.bin_dirs))
        self._bins_listed = True
        bin_numbers = list(sorted(self.bin_dirs.keys()))
        return bin_numbers

    #one-time use utility: found bins with twodigits only, and renamed them to four.
    # def rename_bins(self):
    #
    #     for bin_no, bin_dir in self.bin_dirs.items():
    #         for dir_name, subdir_list, file_list in os.walk(bin_dir):
    #             for fname in file_list:
    #                 #what is before, plus extension beginning with "."
    #
    #                 result = re.search(r"bin(\d\d)\D", fname, re.I)
    #                 if result:
    #
    #                     num = int(result.group(1))
    #                     new_fname = re.sub(r"bin(\d\d)", "bin%d" % num, fname, re.I)
    #                     old_wdir = os.getcwd()
    #                     os.chdir(dir_name)
    #                     os.rename(fname, new_fname)
    #                     os.chdir(old_wdir)
    #                     print("in %s renaming\n%s---> %s" %  (dir_name, fname, new_fname))
    #     return


#----------------------------------------------------------------------------------
    def get_ngs_virome_dir(self):
        '''takes no parameters,
        returns the directory where the virome bins sit'''
        return self.ngs_virome_dir

#----BIN_DIR & NUMS-----------------------------------------------------------------
    def get_bin_dir(self, bin_num):
        '''Takes bin number, returns the full path to the bin dir'''
        bin_str = "%d" % bin_num

        if not bin_num in self.bin_dirs:
            raise IndexError("This bin number is not present in the data set: %s" % bin_str)
        else:
            return os.path.normpath( self.bin_dirs[bin_num] )

    def get_bin_name(self, bin_num):
        '''Takes bin number, returns textual bin name in the usual format
        Checks whether the bin is among the ones in the study.
        e.g. 5 ---> "bin05"
        '''
        bin_str = "bin%d" % bin_num
        if (bin_num < 10):
            bin_str = "bin%02d" % bin_num
        if not bin_num in self.bin_dirs:
            raise IndexError("This bin number is not present in the data set: %s" % bin_str)
        else:
            return bin_str

    def get_bin_nums(self):
        '''returns all bin nums'''
        return sorted(self.bin_dirs.keys())

#----ZIP routines-------------------------------------------------------------------
    def zip_sequence_files(self, bigger_than = 3000000):
        '''Moves data from sequence files bigger than certain limit to zipped files.
        This helps saving disk space. Walks through all directories of the study
        '''
        for bin_no, bin_dir in self.bin_dirs.items():
            for dir_name, subdir_list, file_list in os.walk(bin_dir):
                for fname in file_list:
                    #what is before, plus extension beginning with "."
                    fpathname = os.path.join(dir_name, fname)
                    before_extension, extension = os.path.splitext(fpathname)
                    if re.search(r"^\.(zip|gzip|7z|gz|tar)$", extension, re.I):
                        next #this is already zipped.
                    if (re.search(r"^\.(fasta|fastq|fa|fastqsanger)$", extension, re.I)
                        and os.stat(fpathname).st_size > bigger_than):
                        #this needs to be zipped
                        #if there are both zipped, and unzipped file, we will check the dates of modification,
                        #and remove the zipped file if older. Otherwise the unzipped file will be removed.

                        fzipped = fpathname + '.gz'
                        if os.path.isfile(fzipped) and os.path.getmtime(fzipped) < os.path.getmtime(fpathname):
                            #delete zip file, it is modified EARLIER than unzipped, so the zipped is outdated.
                            os.remove(fzipped)
                        #re check: if it is not here, it may have been deleted because of outdated
                        if not os.path.isfile(fzipped): #make the zip file
                            with open(fpathname , 'rb') as f_in, gzip.open(fzipped, 'wb') as f_out:
                                shutil.copyfileobj(f_in, f_out)
                        #finally, delete the original
                        os.remove(fpathname)
        return



#----VELVET-------------------------------------------------------------------------

    def get_velvet_directory(self, bin_num):
        '''takes bin number
        returns the dir path to the velvet dir, i.e. the dir having the velvet files inside.'''
        return os.path.join( self.get_bin_dir(bin_num) , "velvet")

    def get_fn_velvet_contigs(self, bin_num):
        '''takes bin number
        returns the file path&name to the file with contig consensus sequences from Velvet.'''
        return os.path.join( self.get_velvet_directory(bin_num) , "contigs.fa")

    def get_fn_velvet_unused_reads(self, bin_num):
        '''takes bin number
        returns the file path to the file with 'UnusedReads' after the velvet assembly.'''
        return os.path.join( self.get_velvet_directory(bin_num) , "UnusedReads.fa")

    def get_fn_velvet_asm(self, bin_num):
        '''takes bin number
        returns the file path to the file with the contig alignment details.'''
        return os.path.join(self.get_velvet_directory(bin_num), "velvet_asm.afg")

#----ALL READS------------------------------------------------------------------------
    def get_fn_interlacer_pairs(self, bin_num):
        '''takes bin number
        returns the path and fn to the paired interlaced reads in fastq format'''
        return os.path.normpath(os.path.join(self.get_bin_dir(bin_num), "%s_interlacer_pairs.fastqsanger" % self.get_bin_name(bin_num) ))

    def get_fn_interlacer_singles(self, bin_num):
        '''takes bin number
        returns the path and fn to the singles interlaced reads in fastq format'''
        return os.path.normpath(os.path.join(self.get_bin_dir(bin_num), "%s_interlacer_singles.fastqsanger" % self.get_bin_name(bin_num) ))

    def get_fn_all_reads(self, bin_num):
        '''takes bin number
        returns the list of paths to files containing either interlaced pairs or singles in the bin'''
        fn_all_reads_file = os.path.join(self.get_bin_dir(bin_num), "all_reads%d.fa" % bin_num)
        if (bin_num < 10):
            fn_all_reads_file = os.path.join(self.get_bin_dir(bin_num), "all_reads%02d.fa" % bin_num)
        if not os.path.exists(fn_all_reads_file) or not os.path.isfile(fn_all_reads_file):
            #is it zipped?
            zipname = fn_all_reads_file+".gz"
            if os.path.isfile(zipname):
                unzip(gz_from = zipname, unzip_to = fn_all_reads_file, move = True)
            else:
                print("All reads file for bin %d not present  .... creating" % bin_num)
                with open(fn_all_reads_file, mode = 'w') as outfile:
                    for fname in (self.get_fn_interlacer_pairs(bin_num), self.get_fn_interlacer_singles(bin_num)):
                        zipped_fname = fname+".gz"
                        if not os.path.exists(fname) and os.path.exists(zipped_fname):
                            infile = gzip.open(zipped_fname, mode = "r")    
                        else:
                            infile = open(fname)
                        seqrecords = SeqIO.parse(infile, format="fastq")
                        SeqIO.write(sequences = seqrecords, handle = outfile, format = "fasta")
                        infile.close()
                #We have a problem with gaps in read names. Therefore we will have to ungap the file.
                #rename the original file
                old_filename = fn_all_reads_file + ".old"
                if os.path.exists(old_filename):
                    os.remove(old_filename)
                os.rename(fn_all_reads_file, old_filename)
                #then open the old file
                handle_old = open(old_filename)
                #open the target_file
                handle_new = open(fn_all_reads_file, mode="w")
    
                #read line by line and check whether it is the name
                for line in handle_old:
                    line = line.rstrip()
                    result = re.search(r'^>', line)
                    if result:
                        #it is a name, substitute all gaps
                        line = re.sub(r'\s','_', line)
                    print(line, file=handle_new)
    
                #cleanup
                handle_old.close()
                handle_new.close()
                os.remove(old_filename)
                print(fn_all_reads_file + " .... created" )

        return fn_all_reads_file

#----MEGAN FILES ---------------------------------------------------------------------
    def get_megan_bin_directory(self, bin_num):
        '''takes bin number, returns the dir path to the megan dir, i.e. to random samples of reads
        This is within the data dir of the run'''
        dir_name = os.path.join( self.get_bin_dir(bin_num) , "megan")
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)
        return dir_name

    def get_megan_blast_nt_directory(self, bin_num, sample_size, analysis_type):
        '''parameters:  bin_num = bin number
                        sample_size = desired sample size
                        analysis_type = viruses, bacteria, any sequences...
        returns the directory for megan sample files
        '''
        dir_name = os.path.join(
            self.get_megan_bin_directory(bin_num),
            "bin%d_blast_%s_sample_of_%d" % (bin_num, analysis_type, sample_size)
            )
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)
        return dir_name

    def get_fn_sample_of_reads(self, bin_num, sample_size, make_new_sample = False):
        '''Creates a sample of the given sample size out of all reads from the bin.

        Parameters:
        bin_num = id number of the bin
        ngs_dirs = an instance of object with folders and file names
        sample_size = the count of reads in the sample of reads
        delete_whole_previous (default False) = will the megan_dir be deleted and remade if exists.

        Returns the file name of the sample
        '''


        sample_filename = os.path.join( self.get_bin_dir(bin_num) ,
                            "bin%d_sample_of_%d.fa" % (bin_num, sample_size))

        #make the file if a new has to be made, or if it does not exist
        if make_new_sample or not (os.path.exists(sample_filename) and os.path.isfile(sample_filename)):
            print("will make sample of %d reads from bin %s" % (sample_size, bin_num))
            all_reads_filename = self.get_fn_all_reads(bin_num)
            if (not os.path.exists(all_reads_filename) or not os.path.isfile(all_reads_filename)):
                raise FileNotFoundError("The all_reads.fa file not found for bin %s" %bin_num)

            if os.path.exists(sample_filename):
                os.remove(sample_filename) #delete the old sample if it exists

            _make_a_sample_of_fasta(all_reads_filename, sample_filename, sample_size)

        return sample_filename

#------------------------------------------------------------------------------
    def get_dir_megan_classification(self, query_database = ""):
        '''returns the directory with megan text files showing the taxonomic classification
        e.g. "/ngs_data/ngs_virome/megan_files/dipp96"

        '''
        the_dir = None
        if query_database == "":
            the_dir = os.path.join( self.ngs_virome_dir , "megan_files", self._study)
        else:
            the_dir = os.path.join( self.ngs_virome_dir , "megan_files", self._study, query_database)

        if not os.path.exists(the_dir):
            os.makedirs(the_dir)

        return the_dir



    def get_fn_megan_export_csv(self, bin_num, sample_of, query_database = "nt", analysis_type = ""):
        '''returns the file path to the megan file showing the taxonomic classification'''

        if analysis_type == "":
            megan_fn = os.path.join( self.get_dir_megan_classification(query_database),
                                "bin%d_megan_sample_of_%d_ex.txt" % (bin_num, sample_of))
        else:
            megan_fn = os.path.join( self.get_dir_megan_classification(query_database),
                                "bin%d_megan_%s_sample_of_%d_ex.txt" % (bin_num, analysis_type, sample_of))

        return os.path.normpath(megan_fn)


    def get_fn_megan_rma(self, bin_num, sample_of, query_database="nt", analysis_type=""):
        '''returns the full path + file name of the rma Megan file'''

        the_dir = self.get_dir_megan_classification(query_database)

        if analysis_type == "":
            megan_fn = os.path.join( the_dir,
                                "bin%d_megan_sample_of_%d.rma" % (bin_num, sample_of))
        else:
            megan_fn = os.path.join( the_dir,
                                "bin%d_megan_%s_sample_of_%d.rma" % (bin_num, analysis_type, sample_of))
        return os.path.normpath(megan_fn)

    def get_fn_megan_biome(self, bin_num, sample_of, analysis_type = ""):
        '''returns the full path + name of the biom file produced by MEGAN'''

        megan_fn = os.path.join( self.get_dir_megan_classification(analysis_type),
                                "bin%d_megan_%s_sample_of_%d_taxonomy.biom" % (bin_num, analysis_type, sample_of))
        return os.path.normpath(megan_fn)

    def get_fn_megan_metadata(self, bin_num, sample_of, analysis_type = ""):
        '''returns the full path + name of the metadata file for MEGAN'''
        megan_fn = os.path.join( self.get_dir_megan_classification(analysis_type),
                                "bin%d_megan_%s_sample_of_%d_metadata.txt" % (bin_num, analysis_type, sample_of))
        return os.path.normpath(megan_fn)


#---UNMATCHED CONTIGS AND READS--------------------------------------------------------------------------------
    #def get_fn_unmatched_to_all_viruses(self, bin_num):
    #    '''returns the file path to the file with sequences unmatched to the database of all viruses.'''
    #    return os.path.join( self.get_bin_dir(bin_num) , "blast", "unmatched_to_db_of_all_viruses_bin%d.fa" % bin_num)
    #

    def get_blast_dir(self, bin_num, algorithm, restriction):
        '''returns the dir path to a blast directory.
        Parameters:
        bin_num = number of the bin
        algorithm = blast algorithm (megablast, tblastx)
        restriction = database that was queried (all viruses etc)

        Returns: full dir path
        '''
        return os.path.join( self.get_bin_dir(bin_num) , algorithm + "_" + restriction)

    def get_fn_reads_unmatched_to(self, bin_num, algorithm, restriction):
        '''returns the file path to the file with sequences unmatched to the database
        queried by the method.
        Parameters:
        bin_num = number of the bin
        algorithm = blast algorithm (megablast, tblastx)
        restriction = database that was queried (all viruses etc)

        Returns: full file path

        '''
        return os.path.join( self.get_blast_dir(bin_num, algorithm, restriction), "unmatched_to_db_of_%s_bin%d.fa" % (restriction, bin_num))

    def set_remapping_results_parent(self, parent_name):
        '''sets the working directory for an analysis of unknown sequences
        e.g. 'REMAPPING RESULTS' '''
        self.unknown_sequences_parent = os.path.normpath(os.path.join(self.ngs_virome_dir, parent_name, self._study))
        if not os.path.exists(self.unknown_sequences_parent):
            os.makedirs(self.unknown_sequences_parent)
        return

    def get_remapping_results_parent(self):
        '''returns the parent directory for an analysis of unknown sequences'''
        if not hasattr(self, "unknown_sequences_parent"):
            raise AttributeError("The parent directory for unknown sequences has not been set")
        return self.unknown_sequences_parent

    def get_remapping_results_dir(self, bin_num):
        '''Returns the specific bin directory for the analysis of the unknown sequences'''
        unknown_sequences_dir = os.path.join( self.get_remapping_results_parent(), "bins", "bin%d" % bin_num)
        if not os.path.exists(unknown_sequences_dir):
            os.makedirs( unknown_sequences_dir )
        return unknown_sequences_dir

    def get_sam_dir_remapping(self, bin_num, algorithm = "", restriction = "remapping"):
        '''Returns a directory under the bin for sam files the specific
        mapping to a set of results of given length and coverage'''
        sam_dir = os.path.join(self.get_remapping_results_dir(bin_num), "sam_" + algorithm + "_" + restriction)
        if not os.path.exists(sam_dir):
            os.makedirs( sam_dir )
        return sam_dir

#------------ sam directory for mapping viruses

    def get_sam_dir(self, bin_num, algorithm = "", restriction = ""):
        '''Returns a directory under the bin for sam files the specific
        mapping to a set of results of given length and coverage'''
        sam_dir = os.path.join(self.get_bin_dir(bin_num), "sam_" + algorithm + "_" + restriction)
        if not os.path.exists(sam_dir):
            os.makedirs( sam_dir )
        return sam_dir

    def get_fn_winner_accessions(self, bin_num, algorithm = "", restriction = ""):
        '''Returns the filename with "winners" of blast queries'''
        return os.path.join(self.get_sam_dir(bin_num, algorithm, restriction), "accessions_of_winner_references.txt")
    
#---------- reference contigs ----
    def get_reference_contigs_dir(self):
        '''Returns the reference contigs dir - here the contigs of unknown sequences are stored and curated'''
        reference_contigs_dir = os.path.join( self.get_remapping_results_parent(), "reference_contigs" )
        if not os.path.exists(reference_contigs_dir ):
            os.makedirs( reference_contigs_dir  )
        return reference_contigs_dir

    #-------------------------------------------------------------------
    def get_dir_new_refs(self, min_length, min_coverage):
        '''Directory for storage of new references, for the list of accessions,
        and for remapping results
        e.g. E:/ngs_data/ngs_virome/REMAPPING RESULTS/dipp01/reference_contigs/new_refs_2000_50
        for references having contigs of min. 2000 bases with min 20x coverage'''
        dir_new_refs = os.path.join(self.get_reference_contigs_dir(),
                            "new_refs_%d_%d" % (min_length, min_coverage))
        if not os.path.exists(dir_new_refs):
            os.makedirs( dir_new_refs )
        return dir_new_refs

    def get_fn_tabular_raw_references(self, min_length, min_coverage):
        '''Returns the specific filename for storing raw reference contigs
        before processing, e.g. E:/ngs_data/ngs_virome/REMAPPING RESULTS
            /reference_contigs/new_refs_2000_50/table_of_raw_refs_2000_100.txt'''
        return os.path.join( self.get_dir_new_refs(min_length, min_coverage),
                            "table_of_raw_refs_%d_%d.txt" % (min_length, min_coverage))

    def get_fn_raw_unmatched_references(self, min_length, min_coverage):
        '''Returns the specific filename for storing raw reference contigs
        before processing
        e.g. E:/ngs_data/ngs_virome/REMAPPING RESULTS
                /reference_contigs/new_refs_2000_50/raw_unmatched_contigs_2000_100.fa'''
        return os.path.join( self.get_dir_new_refs(min_length, min_coverage),
                            "raw_unmatched_contigs_%d_%d.fa" % (min_length, min_coverage))

    def get_fn_reduced_list_of_reference_accessions(self, min_length, min_coverage):
        '''returns full path to a list of reference accessions that has to be used in bwa'''
        return os.path.join(self.get_dir_new_refs(min_length, min_coverage),
                            "_final_reference_accession_list_%d_%d.txt" % (min_length, min_coverage) )

    def mapping_outfile(self, min_length, min_coverage, bins_in_study, sample_size):
        '''Returns file path to the new mapping file to unknown contigs'''
        return os.path.join(self.get_dir_new_refs(min_length, min_coverage),
                            "mapping_results_bins_fr%d_to%d_n%d_L%d_C%d_R%d.txt"
                            % (sorted(bins_in_study)[0], sorted(bins_in_study)[-1], len(bins_in_study), min_length, min_coverage, sample_size))

#------------------- main ---------------------------------
if __name__ == '__main__':
    pokus = NgsDirs()
    pokus.get_bins_from_directories(candidate_directories = [r"virome_08_dipp49-72"])
    #print(pokus.bin_dirs)

    print(pokus.get_fn_unmatched_to_all_viruses(55))

    # my_study = NgsDirs("dipp01")
    # my_study.zip_sequence_files()
