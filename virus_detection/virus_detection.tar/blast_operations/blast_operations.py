#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''Multithreaded Blast -
Run the 'split_and_blast' procedure.
    split_sequences_into batches: this will split the files into batches, and return the list of temp files
    multithreaded_blast: this performs the multithreaded blast - local or remote
    and cleans the temporary files (fragments of bigger fasta files)

The result is a set of xml files.

'''


#---IMPORTS-----------------------------------------------------------------------------
import os.path
from os import listdir
from os.path import isfile, join
import time
import datetime
import re

import gzip

import Bio
from Bio.Seq import Seq
from Bio.Sequencing import Ace
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC
from Bio import Entrez
Entrez.email = 'Ondrej.Cinek@gmail.com'

from Bio import SeqIO

import threading
import queue

#-------------- GLOBALS ------------------------

BLAST_DIR       = "/data/virology/tools/blast/db"
BLAST_BIN_DIR   = "/data/virology/tools/blast/bin"

#-------------------------------------------------------------
# Multithreaded implementation of BLAST
#-------------------------------------------------------------

#----------------------- classes --------------------------------
class Worker(threading.Thread):
    '''
    for internal use
    This is a subclassed Thread - one process in the multithreaded execution.
    It has an __init__ method
    and a run method

    The run method calls either a local, or remote process on a batch of fasta sequences.
    '''

    def __init__(self,
                 work_queue,
                 restriction,
                 local_execution = False,
                 depth_blast = 10,
                 evalue = 0.1,
                 algorithm = "megablast",
                 num_threads = 3
                 ):
        #must have an __init__
        super().__init__() #here it calls the parental __init__
        self.work_queue = work_queue #and here it takes a queue as an argument!
        self.local_execution = local_execution
        self.restriction = restriction
        self.depth_blast = depth_blast
        self.evalue = evalue
        self.algorithm = algorithm
        self.num_threads = num_threads

    def run(self): #it MUST implement also a method call "run"
        while True: #it is an infinite loop

            blast_query = []

            try: #first it takes another task from the queue
                #this is universal - take something from the queue
                blast_query = self.work_queue.get()

                #and performs a specific task with it
                output_filename = blast_query[0]
                input_filename  = blast_query[1]
                #time.sleep(3)

                if self.local_execution:
                    #this is for the LOCAL blast
                    local_blast_batch(input_filename,
                                      output_filename,
                                      restriction   = self.restriction,
                                      depth_blast   = self.depth_blast,
                                      evalue        = self.evalue,
                                      algorithm     = self.algorithm,
                                      num_threads   = self.num_threads
                                      )
                else:
                #this is for REMOTE blast
                    remote_blast_batch(input_filename,
                                       output_filename,
                                       restriction  = self.restriction,
                                       depth_blast  = self.depth_blast,
                                       algorithm     = self.algorithm
                                       )
            except queue.Empty as e: #this is raised when the queue is empty
                pass #ignore an index error, proceeds to the finally block
            except (IOError, ValueError) as e: #IOError, ValueError
                print(e)
                #puts the unsuccessful blast query BACK into the queue!
                self.work_queue.put(blast_query)
            finally: #and finally, regardless of what the result is, it informs the queue
                     #that the work has been done. It appears to be just a counter
                     #for the join() method.
                self.work_queue.task_done()



#-----------BLAST queries----------------------------------------------
def remote_blast_batch(source_fname, #the file with fasta sequences
                       target_fname,
                       restriction = None,
                       depth_blast = 10,
                       evalue = 0.01,
                       algorithm = "megablast"):
    '''
    internal use - called by WORKER (the multithreading process)
    Obtains a result of a blast query ONLINE, and saves it to the file name provided

    Parameters:
    source_fname = the filename with one or multiple fasta sequences
    target_fname = the path and name for the output xml file
    restriction = to what organisms the query should be limited
    depth_blast = number of matching organisms that will be reported for each sequence
    evalue = e-value, the number of expected hits by chance
    algorithm = the BLAST algorithm; most often the "megablast"
    '''

    if algorithm != "megablast":
        raise NotImplementedError("Other algorithms than megablast not yet implemented")

    text_fh = open(source_fname, mode = "r")
        #all fasta records in one text
    text_seq = "".join(text_fh.readlines())

    #this is a remote blast - therefore there is one nt database, and the restriction is done
    #using an [organism] constraint
    entrez_string = ''
    if restriction == 'enterovirus':
        entrez_string = 'enterovirus[organism]'
    elif restriction == 'picornaviridae':
        entrez_string = "txid12058[Orgn]" #Picornaviridae
    elif restriction == 'all_viruses':
        entrez_string = "txid10239[Orgn]" #viruses
    elif restriction == 'bacteria':
        entrez_string = "txid2[Orgn]" #bacteria - yes, this is such a short one
    else:
        pass

    try:
        #(1) make a handle from a BLAST query
        #print("query sent for %s file" %(target_fname))
        start = time.time()
        fh = NCBIWWW.qblast(program = "blastn",
                            database = "nt",   #is "nt" for nocleotide. nr is non redundant protein....
                            sequence = text_seq,
                            expect=evalue,
                            alignments = 10,
                            hitlist_size=depth_blast,
                            entrez_query = entrez_string,
                            nucl_reward = 1,                 # as in the web version
                            nucl_penalty = -2,               # as in the web version
                            #gapcosts = "linear",  #leave the default values; this is default with megablast
                            megablast = "true",
                            #get only matches that fulfil this entrez constraint
                            #this makes things simpler as to the number of matches.

                            )
    except ValueError as e:
        print("query failed ", e)
        raise
    except IOError as e:
        print("query timed out ", e)
        raise
    else:
        #print("response receeived for %s file in %f seconds" %(target_fname, time.time()-start))
        #(2) make a permanent file of this search
        target_fh = open(target_fname, mode="w")
        results = fh.read() # this yields an xml text
        target_fh.write(results)
        target_fh.close()
        return

def local_blast_batch(input_fname, target_fname, restriction = None,
                      depth_blast = 10, evalue = 0.1, algorithm = "megablast",
                      num_threads = 6 ):
    '''
    internal use - called by WORKER (the multithreading process)
    Obtains a result of a blast query done locally, and saves it to the file name provided.
    The result is an xml file with the BLAST output.

    Parameters:
    input_fname = the filename with one or multiple fasta sequences
    target_fname = the path and name for the output xml file
    restriction = to what organisms the query should be limited.
    entrez_string = additional condition for the entrez query
    evalue = e-value, the number of expected hits by chance
    num_threads = real number of processor cores dedicated to the task
    algorithm = the BLAST algorithm; most often the "megablast"
    '''

    #this is a local blast, therefore the restriction is done using selection of the database
    database = ""
    if restriction == 'enterovirus':
        database = 'nt_enterovirus' #enteroviruses, smallest database
    elif restriction == 'all_viruses':
        database = 'nt_all_viruses' #all full length viruses, including the plant viruses, phages etc...
    elif restriction == 'picornaviridae':
        database = 'nt_picornaviridae' #picornaviruses - slightly bigger than enteroviruses
    elif restriction == '16S':
        database = '16SMicrobial' #the official database by NCBI
    elif restriction == 'ribosomes':
        database = 'ribosomes' #custom database of all bacterial ribosomal DNA
    elif restriction == 'human':
        database = 'human_genomic' #from NCBI
    else:
        database = "nt"
        print ("WARNING!!!! Database = 'nt'\nUnrestricted blast will take a very long time!!!" )

    #BLAST+ uses the "-num_threads" flag to specify the number of worker threads to create.
    #In order to specify the correct number of cores for the job, you will need to ADD ONE to the number of threads specified.
    #This is to account for the number of worker threads, PLUS the main process thread.

    #print("Local BLAST query sent for %s file" %(target_fname))
    start = time.time()
    if algorithm == "megablast":
        blast_cmd_text= ('blastn -db %s -task megablast -query %s -out %s -outfmt 5 -evalue %f -num_alignments %d -num_threads %d'
                        %
                        ( database,  input_fname, target_fname, evalue, depth_blast, num_threads)
                        )
        #perform blastn megablast on the query file ... with output file ... with outut format 5 (xml)
        #and very low e-value; show only top 10 alignments
        #print("BLAST query: %s" % blast_cmd_text)
    elif algorithm == "tblastx":
        blast_cmd_text= ('tblastx -db %s -query %s -out %s -outfmt 5 -evalue %f -num_alignments %d -num_threads %d'
                        %
                        ( database,  input_fname, target_fname, evalue, depth_blast, num_threads)
                        )
    else:
        raise ValueError("Unknown type of query algorithm")

    try:
        #perform the command as if it were sent to the "command window"
        os.chdir(BLAST_BIN_DIR)

        with open("blast_cmd.txt", mode="a", buffering = -1) as handle:
            print(blast_cmd_text, file = handle)
        print(blast_cmd_text)

        os.system(blast_cmd_text)

    except Exception as e: #if there is an exception, print it and re-raise
        print(e)
        raise

    return


#--------------------- subroutines -------------------------
def multithreaded_blast(batches,
                        restriction,
                        local_execution = True,
                        depth_blast = 10,
                        evalue = 0.1,
                        num_processes = 2,
                        num_threads = 3,
                        algorithm = "megablast"):
    """ calls the blast for each of the segments stored in dict batches
    (where the key is the OUTPUT XML file name and the value is the INPUT fasta filename)

    Because it was so slow sequentially using remote BLAST, there is a multithreaded implementation.
    It is likely that the local implementation utilizes more processor cores as compared to using
    a single thread only.
    """

    work_queue = queue.Queue() #defines a queue of data for processing.
    #the queue object handles locking, and is a standard solution to multithreading in Python

    #start empty processes
    for i in range(num_processes): #max number of processes
        worker = Worker(work_queue,
                        local_execution = local_execution,
                        restriction = restriction,
                        depth_blast = depth_blast,
                        evalue = evalue,
                        algorithm = algorithm,
                        num_threads = num_threads
                        ) #does megablast unless specified otherwise, e.g. tblastx
        #new instance of the Worker class (beware, you Marxist)
        #the restriction is the viruses/pricornaviridae/enterovirus selection,and is done by a global var
        worker.daemon = True #this will finish the program when done
                             #(a step needed for synchronised execution)
        time.sleep(1) #no idea why. It seemed to work better with the remote queries,
                      #but probably useless with the local ones
        worker.start() #start this instance of worker


    #now we will tell the workers what to do - we will fill the queue
    for (output_filename, input_filename) in batches.items(): #for each batch of sequences
        #put the name of the output file and the query
        work_queue.put([output_filename, input_filename])
        #in the queue. The member will be as an array.
        time.sleep(2)

    print("       The work queue defined")
    work_queue.join() #blocks until the queue is empty (another step needed for synchronised execution)

    print("       Mulitithreaded local blast done")
    return


def split_sequences_into_batches(all_sequences, batches, outputdir,
                                 list_fnames, nmaxseq = 5000,
                                 add_blast_xml_result_to_deleted = False,
                                 remove_garbage = True):
    '''runs the actual procedure of splitting a file with fasta sequences into batches

    batches = batches of files, a dict.
    list_fnames = lists paths where the files are
    outputdir = directory for splitting the files
    '''

    temp_files = set()

    #create outputdir if not exists
    if not os.path.exists(outputdir):
        os.makedirs(outputdir)

    if not list_fnames:
        raise ValueError("No list of files to process")
    else: #finally got to work
        sourcedir = ''
        for (i, fname) in enumerate(list_fnames):
            dirname, filename = os.path.split(fname)
            if sourcedir == '':
                sourcedir = dirname
            elif sourcedir != dirname:
                raise ValueError("FATAL ERROR!\nThe file %s is in other directory\n than the others. Terminating!")
            else:
                pass #everyhing OK, the files are held in one directory
            if i == 0: #first pass, open a garbage file
                fh_garbage = None
                if remove_garbage:
                    fn_garbage = os.path.join(outputdir, "garbage_sequences.fa")
                    fh_garbage = open(fn_garbage, mode="w", buffering = -1)
            temp_files_part = split_one_sequence_file_in_parts(all_sequences,
                                                               batches,
                                                               fname,
                                                               fh_garbage, #if set to None, removes nothing
                                                               outputdir,
                                                               nmaxseq,
                                                               add_blast_xml_result_to_deleted)
            temp_files.update(temp_files_part)
        if fh_garbage is not None:
            fh_garbage.close()
    return temp_files

def split_one_sequence_file_in_parts(all_sequences, batches, fname,
                                     fh_garbage, outputdir, nmaxseq = 5000,
                                     add_blast_xml_result_to_deleted = False):
    '''
    Called by 'split_sequences_into_batches'


    splits the fasta file of given filename(incl path)
    into a set of fasta files with a suffix "_part_n.fa" where n is 1..x
    Also makes the filename for the xml, puts the batch in a queue and also
    puts the batch into a dict of output ant input files "batches".

    Filters the sequences for the most obvious garbage, and puts that into the garbage filehandle
    '''
    temp_files = set( )

    #fname is with path, let us have only the fname:
    origdir, fname_core = os.path.split(fname)
    fh = None
    typefile = ""

    #what is it? Is it zipped?
    (base, ext) = os.path.splitext(fname)
    if ext == ".gz":
        (base2, ext2) = os.path.splitext(base)
        if ext2 == ".fastq":
            typefile = "fastq"
            fh = gzip.open(fname)
        elif ext2 == ".fa" or ext2 == ".fasta":
            typefile = "fasta"
            fh = gzip.open(fname)
    else:
        if ext == ".fastq":
            typefile = "fastq"
            fh = open(fname)
        elif ext == ".fa" or ext == ".fasta":
            typefile = "fasta"
            fh = open(fname)

    #initate the parser
    parser = SeqIO.parse(fh, typefile)

    batch_counter = 1
    batch = give_one_batch(parser, all_sequences, nmaxseq, fh_garbage) #the first batch in the cycle
    while len(batch)>0:
        #open file
        output_fa_fn     = os.path.join(outputdir, fname_core.replace(ext, "_part" + str(batch_counter) + ".fa"))
        output_blast_fn  = os.path.join(outputdir, fname_core.replace(ext, "_part" + str(batch_counter) + "_result.xml"))

        temp_files.add(output_fa_fn)
        if add_blast_xml_result_to_deleted:
            temp_files.add(output_blast_fn)

        with open(output_fa_fn, mode="w") as handle_output_fa:
            SeqIO.write(batch, handle_output_fa, "fasta")
        #for later multithreaded use of BLAST: key = output filename, value = input filename
        batches[output_blast_fn] = output_fa_fn
        #before another iteration
        batch = give_one_batch(parser, all_sequences, nmaxseq, fh_garbage)
        batch_counter += 1

    fh.close()
    return temp_files


def give_one_batch(parser,
                   all_velvet_sequences = None,
                   required_size_of_batch = 5000,
                   fh_garbage = None
                   ):
    '''Returns an array of Biopython Fasta records that is the required size
    of the batch.

    Parameters:
    parser = an iterator (SeqIO.parse) that yield one sequence per iteration
        this is because it is prepared also for fastq files.
    required size of the batch = size of one batch, in number of sequences
    fh_garbage = where the garbage will be printed

    Returns an array of fasta Biopython seqrecords
    '''


    reads = []
    processed_reads = 0

    while processed_reads < required_size_of_batch:
        try:
            seqrecord = next(parser)
        except StopIteration as e:
            break
        #if it is not StopIteration...
        thrash = 0 #flag
        if not fh_garbage is None:
            #existuje-li fh na garbage (tedy se sbírá)
            garbage_patterns = ['^G?(TG)+T?$',
                                '^A?(CA)+C?$',
                                '^G?A?C?A?(GACA)+G?A?C?A?$',
                                '^T?G?T?C?(TGTC)+T?G?T?C?$' ]
            sequence_text = str(seqrecord.seq)
            for pattern in garbage_patterns:
                result = re.search(pattern, sequence_text, re.IGNORECASE)
                if result:
                    thrash = 1
                    SeqIO.write(seqrecord, fh_garbage, "fasta")
                    break
        if not thrash:
            reads.append(seqrecord)
            if not all_velvet_sequences is None:
                all_velvet_sequences[seqrecord.description] = str(seqrecord.seq)
            processed_reads +=1

    return reads


# ======== main procedure ======
def split_and_blast(outputdir, list_files, restriction = "nt",
                    local_execution = True,
                    depth_blast = 10,
                    evalue = 0.001, nmaxseq = 5000, delete_blast_xml = False,
                    num_processes = 3, num_threads = 3, remove_garbage = True, algorithm = "megablast"):
    '''
Splits a large file into parts, and blasts each of the parts
outputdir   = directory for the resulting xml files
list_files  = a list with the files with fasta records
restriction = what database? what restriction?
    nt,
    enterovirus (i.e. enterovirs[organism])
    picornaviridae (i.e. txid12058[Orgn])
    all_viruses (i.e. exid10239[Orgn])
    16S ... the respective database
    bacteria (i.e. txid2[Orgn])
    ribosomes (a custom ribosomal bacterial database)
local_execution = true if the blast is run on the local machine
algorithm = what algorithm should be used. Now only the nucleotide match algorithms are implemented.
depth_blast = how deep the report should be , 10 default
evalue      = hits expected just by chance. The lower value, the more stringent search
nmaxseq     = max number of sequences in a batch for the blast
delete_blast_xml = should the xml result files be added to the set of temp files
num_threads     = number of threads for the process (if local)
remove_garbage  = if set to True, the splitting algorithm checks for apparently artifacts, and removes them

Returns: a dict {output_filename1:input_filename1, output_filename2:input_filename2, etc... }

    '''

    print( "\n----------------------------\nFile splitting started...\n---------------------------\n" )
    #first split the files whose names are in the listbox_fastq,
    batches = dict()
    all_sequences = dict()

    temp_files1 = split_sequences_into_batches(all_sequences,
                                               batches,
                                               outputdir,
                                               list_fnames = list_files,
                                               nmaxseq = nmaxseq,
                                               add_blast_xml_result_to_deleted = delete_blast_xml,
                                               remove_garbage = remove_garbage
                                               )
    #ends up with the chunks of fasta files, and full dict of "batches"

    #then run their blast
    print("\n------------------------\nStarting the multithreaded BLAST...\n-------------------------")
    multithreaded_blast(batches,
                        restriction = restriction,
                        local_execution = True,
                        depth_blast = depth_blast,
                        evalue = evalue,
                        num_processes = num_processes,
                        num_threads = num_threads,
                        algorithm = algorithm)

    #clean up the temporary files
    for one_file in temp_files1:
        one_file = os.path.normpath(one_file)
        try:
            os.remove(one_file)
            print("removed %s" % one_file )
        except Exception as e:
            print("ERROR: %s when deleting file %s" % (e, one_file))

    return batches




if __name__ == '__main__':
    pass
