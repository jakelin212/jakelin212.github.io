#/usr/local/bin/python3 

#usr/bin/python
from __future__ import print_function

import os.path
import os
import sys

sys.path.append('../') 

import configparser

config = configparser.RawConfigParser()
config.read('/var/www/cgi-bin/virp/scripts/ref_bin.cfg')

# getfloat() raises an exception if the value is not a float
# getint() and getboolean() also do this for their respective types
kmer = config.get('ref_bin_exec', 'kmer')

 
data_dir = "/media/sf_ngs_data/ngs_virome/virome_08_dipp49-72/data"
velvetprogdir = "/home/ngsuziv/velvet_1.2.10/"
velvetprojdir = "/usr/local/bin/"

def assemble_bin(  binnum, bin_dir, velvetprogdir = "/usr/local/bin/"):    
    ''' launches the velvet job for the specified files'''
    
    
    #we will work relative to the bin_dir
    os.chdir(bin_dir)
    print("CURRENTLY IN %s" % os.getcwd())
    #how is the velvet dir named and does it exist?
    velvetdir = "velvet"#+kmer
    if not(os.path.exists(velvetdir) and os.path.isdir(velvetdir)):
        os.mkdir(velvetdir)

    #names of the directories
    pairsfile   = os.path.join(bin_dir, "bin%02d_interlacer_pairs.fastqsanger" % binnum)
    singlesfile = os.path.join(bin_dir, "bin%02d_interlacer_singles.fastqsanger" % binnum)

    #run velveth
    velveth_command = "velveth %s %s -fastq -shortPaired %s -short %s" % (velvetdir, kmer, pairsfile, singlesfile)
    
    print(velveth_command)
    os.system(velveth_command)
    
    velvetg_command = velvetprogdir + "velvetg %s -exp_cov 50 -ins_length 300 -cov_cutoff 5 -min_contig_lgth 150 -unused_reads yes -amos_file yes" % velvetdir
    velvetg_command = velvetprogdir + "velvetg %s -exp_cov 50 -ins_length 300 -cov_cutoff 5 -min_contig_lgth 150 -unused_reads yes -amos_file yes" % velvetdir    
    print(velvetg_command)
    os.system(velvetg_command)

    print()
    print()
    

if __name__ == '__main__':
    base_dir = "/media/sf_ngs_data/ngs_virome/virome_07_dipp73-96"
    #base_dir = config.get("paths", "basedir")#paths_and_references.getBasedir()
    if (len(sys.argv) < 3):
        print("requires bin range, if more than 3 parameters, upgrate program to parse on list of bins")
        sys.exit()
    startbin = int(sys.argv[1])
    endbin = int(sys.argv[2])

    for bin_num in range(74, 96):
        bin_dir = os.path.join(base_dir, "data", "bin%02d" % bin_num)
        print(bin_dir)
        process_bin(bin_dir, bin_num)
        script_for_velvet.assemble_bin(bin_num, bin_dir)

    print("A routine for processing the velvet de novo assembly")
